import React from 'react';
import { Clock, TrendingUp } from 'lucide-react';
import { CulturalContent } from '../types';

interface TimelineProps {
  content: CulturalContent[];
  selectedDecade: string;
}

const Timeline: React.FC<TimelineProps> = ({ content, selectedDecade }) => {
  const years = Array.from(new Set(content.map(item => item.year))).sort();
  
  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-2xl p-6 mb-8">
      <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
        <Clock className="w-6 h-6 text-purple-600" />
        Cultural Timeline
        {selectedDecade && (
          <span className="text-lg text-purple-600 font-medium">- {selectedDecade}</span>
        )}
      </h2>
      
      <div className="relative">
        {/* Timeline Line */}
        <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gradient-to-b from-purple-400 to-pink-400"></div>
        
        <div className="space-y-6">
          {years.map((year, index) => {
            const yearContent = content.filter(item => item.year === year);
            const totalPopularity = yearContent.reduce((sum, item) => sum + item.popularity, 0) / yearContent.length;
            
            return (
              <div key={year} className="relative flex items-start">
                {/* Timeline Dot */}
                <div className="relative z-10 w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white font-bold shadow-lg">
                  <TrendingUp className="w-5 h-5" />
                </div>
                
                {/* Content */}
                <div className="ml-6 flex-1">
                  <div className="bg-white/90 rounded-xl p-4 shadow-lg hover:shadow-xl transition-shadow duration-200">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-xl font-bold text-gray-800">{year}</h3>
                      <div className="text-sm text-gray-600">
                        {yearContent.length} items • {Math.round(totalPopularity)}% avg popularity
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {yearContent.slice(0, 4).map((item) => (
                        <div
                          key={item.id}
                          className="p-2 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-150"
                        >
                          <p className="font-medium text-sm text-gray-800 truncate">{item.title}</p>
                          <p className="text-xs text-gray-600">{item.type}</p>
                        </div>
                      ))}
                    </div>
                    
                    {yearContent.length > 4 && (
                      <p className="text-sm text-purple-600 mt-2">
                        +{yearContent.length - 4} more items
                      </p>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default Timeline;