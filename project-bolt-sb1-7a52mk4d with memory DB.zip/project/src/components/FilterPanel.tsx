import React from 'react';
import { Calendar, Heart, Users, Filter } from 'lucide-react';
import { decades, moods, lifeEvents } from '../data/content';

interface FilterPanelProps {
  selectedDecade: string;
  selectedMoods: string[];
  selectedLifeEvents: string[];
  onDecadeChange: (decade: string) => void;
  onMoodToggle: (mood: string) => void;
  onLifeEventToggle: (event: string) => void;
  onClearFilters: () => void;
}

const FilterPanel: React.FC<FilterPanelProps> = ({
  selectedDecade,
  selectedMoods,
  selectedLifeEvents,
  onDecadeChange,
  onMoodToggle,
  onLifeEventToggle,
  onClearFilters,
}) => {
  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-2xl p-6 sticky top-4">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
          <Filter className="w-6 h-6 text-purple-600" />
          Time Travel Controls
        </h2>
        <button
          onClick={onClearFilters}
          className="text-sm text-purple-600 hover:text-purple-800 font-medium"
        >
          Clear All
        </button>
      </div>

      {/* Decade Selection */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-gray-700">
          <Calendar className="w-5 h-5" />
          Choose Your Era
        </h3>
        <div className="grid grid-cols-2 gap-2">
          {decades.map((decade) => (
            <button
              key={decade}
              onClick={() => onDecadeChange(decade)}
              className={`p-3 rounded-xl font-medium transition-all duration-200 ${
                selectedDecade === decade
                  ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg transform scale-105'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200 hover:shadow-md'
              }`}
            >
              {decade}
            </button>
          ))}
        </div>
      </div>

      {/* Mood Selection */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-gray-700">
          <Heart className="w-5 h-5" />
          Set the Mood
        </h3>
        <div className="flex flex-wrap gap-2">
          {moods.map((mood) => (
            <button
              key={mood}
              onClick={() => onMoodToggle(mood)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                selectedMoods.includes(mood)
                  ? 'bg-gradient-to-r from-blue-500 to-teal-500 text-white shadow-md transform scale-105'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200 hover:shadow-sm'
              }`}
            >
              {mood}
            </button>
          ))}
        </div>
      </div>

      {/* Life Events Selection */}
      <div>
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-gray-700">
          <Users className="w-5 h-5" />
          Life Moments
        </h3>
        <div className="flex flex-wrap gap-2">
          {lifeEvents.map((event) => (
            <button
              key={event}
              onClick={() => onLifeEventToggle(event)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                selectedLifeEvents.includes(event)
                  ? 'bg-gradient-to-r from-green-500 to-emerald-500 text-white shadow-md transform scale-105'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200 hover:shadow-sm'
              }`}
            >
              {event}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default FilterPanel;