import React, { useState, useEffect } from 'react';
import { User, Key, Brain, Save, Settings, Check } from 'lucide-react';
import { llmProviders } from '../data/llmProviders';
import { UserProfile } from '../types';

interface ProfilePageProps {
  onSave: (profile: UserProfile) => void;
  currentProfile?: UserProfile;
  onBack?: () => void;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ onSave, currentProfile, onBack }) => {
  const [profile, setProfile] = useState<Partial<UserProfile>>({
    name: '',
    email: '',
    llmProvider: 'openai',
    llmApiKey: '',
    llmModel: 'gpt-4',
    preferences: {
      defaultDecade: '',
      favoriteGenres: [],
      culturalInterests: [],
    },
    ...currentProfile,
  });

  const [showApiKey, setShowApiKey] = useState(false);
  const [saved, setSaved] = useState(false);

  const selectedProvider = llmProviders.find(p => p.id === profile.llmProvider);

  const handleSave = () => {
    if (!profile.llmApiKey || !profile.qlooApiKey) {
      alert('Please enter both LLM and Qloo API keys');
      return;
    }

    const userProfile: UserProfile = {
      id: currentProfile?.id || Date.now().toString(),
      name: profile.name || 'Anonymous User',
      email: profile.email || '',
      llmProvider: profile.llmProvider!,
      llmApiKey: profile.llmApiKey!,
      llmModel: profile.llmModel!,
      qlooApiKey: profile.qlooApiKey!,
      preferences: profile.preferences!,
      createdAt: currentProfile?.createdAt || new Date(),
      updatedAt: new Date(),
    };

    onSave(userProfile);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const culturalInterests = [
    'Music', 'Movies', 'Fashion', 'Technology', 'Food', 'Travel', 
    'Art', 'Literature', 'Sports', 'Gaming', 'Politics', 'Science'
  ];

  const musicGenres = [
    'Rock', 'Pop', 'Hip-Hop', 'Electronic', 'Jazz', 'Classical',
    'Country', 'R&B', 'Indie', 'Metal', 'Folk', 'Reggae'
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-pink-50 to-indigo-100 p-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl p-6 mb-6">
          <div className="flex items-center gap-3 mb-4">
            <Settings className="w-8 h-8 text-purple-600" />
            <h1 className="text-2xl font-bold text-gray-800">Profile Settings</h1>
          </div>
        </div>

        {/* Profile Form */}
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl p-8">
          {/* Basic Info */}
          <div className="mb-8">
            <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center gap-2">
              <User className="w-5 h-5" />
              Basic Information
            </h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Name</label>
                <input
                  type="text"
                  value={profile.name || ''}
                  onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                  className="w-full p-3 border border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none"
                  placeholder="Your name"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                <input
                  type="email"
                  value={profile.email || ''}
                  onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                  className="w-full p-3 border border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none"
                  placeholder="your@email.com"
                />
              </div>
            </div>
          </div>

          {/* LLM Configuration */}
          <div className="mb-8">
            <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center gap-2">
              <Brain className="w-5 h-5" />
              AI Configuration
            </h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">LLM Provider</label>
                <select
                  value={profile.llmProvider}
                  onChange={(e) => {
                    const provider = llmProviders.find(p => p.id === e.target.value);
                    setProfile({ 
                      ...profile, 
                      llmProvider: e.target.value,
                      llmModel: provider?.models[0] || ''
                    });
                  }}
                  className="w-full p-3 border border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none"
                >
                  {llmProviders.map((provider) => (
                    <option key={provider.id} value={provider.id}>
                      {provider.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Model</label>
                <select
                  value={profile.llmModel}
                  onChange={(e) => setProfile({ ...profile, llmModel: e.target.value })}
                  className="w-full p-3 border border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none"
                >
                  {selectedProvider?.models.map((model) => (
                    <option key={model} value={model}>
                      {model}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  API Key
                  <span className="text-red-500 ml-1">*</span>
                </label>
                <div className="relative">
                  <input
                    type={showApiKey ? 'text' : 'password'}
                    value={profile.llmApiKey || ''}
                    onChange={(e) => setProfile({ ...profile, llmApiKey: e.target.value })}
                    className="w-full p-3 pr-12 border border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none"
                    placeholder="Enter your API key"
                  />
                  <button
                    type="button"
                    onClick={() => setShowApiKey(!showApiKey)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                  >
                    <Key className="w-5 h-5" />
                  </button>
                </div>
                <p className="text-sm text-gray-500 mt-1">
                  Your API key is stored locally and never shared
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Qloo API Key
                  <span className="text-red-500 ml-1">*</span>
                </label>
                <div className="relative">
                  <input
                    type={showApiKey ? 'text' : 'password'}
                    value={profile.qlooApiKey || ''}
                    onChange={(e) => setProfile({ ...profile, qlooApiKey: e.target.value })}
                    className="w-full p-3 pr-12 border border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none"
                    placeholder="Enter your Qloo API key"
                  />
                  <button
                    type="button"
                    onClick={() => setShowApiKey(!showApiKey)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                  >
                    <Key className="w-5 h-5" />
                  </button>
                </div>
                <p className="text-sm text-gray-500 mt-1">
                  Required for cultural recommendations
                </p>
              </div>
            </div>
          </div>

          {/* Preferences */}
          <div className="mb-8">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Cultural Preferences</h2>
            
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Default Decade</label>
                <select
                  value={profile.preferences?.defaultDecade || ''}
                  onChange={(e) => setProfile({ 
                    ...profile, 
                    preferences: { 
                      ...profile.preferences!, 
                      defaultDecade: e.target.value 
                    }
                  })}
                  className="w-full p-3 border border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none"
                >
                  <option value="">Select a decade</option>
                  <option value="1980s">1980s</option>
                  <option value="1990s">1990s</option>
                  <option value="2000s">2000s</option>
                  <option value="2010s">2010s</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">Favorite Music Genres</label>
                <div className="flex flex-wrap gap-2">
                  {musicGenres.map((genre) => (
                    <button
                      key={genre}
                      onClick={() => {
                        const current = profile.preferences?.favoriteGenres || [];
                        const updated = current.includes(genre)
                          ? current.filter(g => g !== genre)
                          : [...current, genre];
                        setProfile({
                          ...profile,
                          preferences: { ...profile.preferences!, favoriteGenres: updated }
                        });
                      }}
                      className={`px-3 py-2 rounded-full text-sm font-medium transition-all ${
                        profile.preferences?.favoriteGenres?.includes(genre)
                          ? 'bg-purple-500 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      {genre}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">Cultural Interests</label>
                <div className="flex flex-wrap gap-2">
                  {culturalInterests.map((interest) => (
                    <button
                      key={interest}
                      onClick={() => {
                        const current = profile.preferences?.culturalInterests || [];
                        const updated = current.includes(interest)
                          ? current.filter(i => i !== interest)
                          : [...current, interest];
                        setProfile({
                          ...profile,
                          preferences: { ...profile.preferences!, culturalInterests: updated }
                        });
                      }}
                      className={`px-3 py-2 rounded-full text-sm font-medium transition-all ${
                        profile.preferences?.culturalInterests?.includes(interest)
                          ? 'bg-blue-500 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      {interest}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Save Button */}
          <div className="flex justify-end">
            <button
              onClick={handleSave}
              disabled={!profile.llmApiKey || !profile.qlooApiKey}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all ${
                saved
                  ? 'bg-green-500 text-white'
                  : 'bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed'
              }`}
            >
              {saved ? (
                <>
                  <Check className="w-5 h-5" />
                  Saved!
                </>
              ) : (
                <>
                  <Save className="w-5 h-5" />
                  Save Profile
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;