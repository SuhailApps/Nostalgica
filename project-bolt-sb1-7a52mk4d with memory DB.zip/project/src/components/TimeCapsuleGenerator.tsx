import React, { useState, useEffect } from 'react';
import { Loader2, Sparkles, Clock, Brain } from 'lucide-react';
import { OnboardingData, TimeCapsule, UserProfile, PlaylistItem, StarterPackItem } from '../types';
import { LLMService } from '../services/llmService';
import { QlooService } from '../services/qlooService';
import { QlooRecommendation } from '../types';

interface TimeCapsuleGeneratorProps {
  onboardingData: OnboardingData;
  userProfile: UserProfile;
  onComplete: (capsule: TimeCapsule) => void;
  onCancel: () => void;
}

const TimeCapsuleGenerator: React.FC<TimeCapsuleGeneratorProps> = ({
  onboardingData,
  userProfile,
  onComplete,
  onCancel
}) => {
  const [stage, setStage] = useState<'processing' | 'generating' | 'complete'>('processing');
  const [progress, setProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [hasError, setHasError] = useState(false);

  // Dynamic context-driven generation using LLM
  const generateContextualContent = async (
    category: string,
    context: {
      year: number;
      location: string;
      lifeEvent: string;
      mood: string;
      decade: string;
    }
  ): Promise<{ name: string; description: string; icon: string }> => {
    const llmService = new LLMService(userProfile);
    
    const prompt = `Based on the following context, generate a single ${category} item that would be culturally relevant and authentic:

Context:
- Year: ${context.year}
- Location: ${context.location}
- Life Event: ${context.lifeEvent}
- Mood: ${context.mood}
- Decade: ${context.decade}

Generate a JSON response with:
{
  "name": "specific item name",
  "description": "2-3 sentence description of cultural relevance",
  "icon": "single emoji that represents this item"
}

Make it authentic to the location and time period. For example:
- For 1981 India fashion: "Bell-bottom pants" not "skinny jeans"
- For 1990s India food: "Maggi noodles" not "ramen"
- For 2000s India travel: "Train journeys" not "budget airlines"

Respond only with valid JSON.`;

    try {
      const response = await llmService.callLLMDirect(prompt);
      const parsed = JSON.parse(response.match(/\{[\s\S]*\}/)?.[0] || '{}');
      
      return {
        name: parsed.name || `${category} item`,
        description: parsed.description || `A culturally relevant ${category} item from ${context.year}`,
        icon: parsed.icon || '🎯'
      };
    } catch (error) {
      console.error(`Error generating ${category} content:`, error);
      return {
        name: `${category} item`,
        description: `A culturally relevant ${category} item from ${context.year} in ${context.location}`,
        icon: '🎯'
      };
    }
  };

  // Generate culturally accurate playlist using LLM with cultural categories
  const generatePlaylistFromCulturalCategories = async (
    musicCategories: string[],
    context: {
      year: number;
      location: string;
      lifeEvent: string;
      mood: string;
    }
  ): Promise<PlaylistItem[]> => {
    if (!musicCategories.length) {
      return getLocationAwareMusicFallbacks(context.location, context.year).slice(0, 5);
    }

    const prompt = `Based on these cultural music categories from ${context.year} ${context.location}, generate specific song titles and artists:
    
Cultural Categories: ${musicCategories.join(', ')}
Context: ${context.lifeEvent} in ${context.location}, ${context.year}
Mood: ${context.mood}

Generate a JSON array of exactly 5 songs that match these categories:
[
  {
    "title": "Exact Song Title",
    "artist": "Artist Name",
    "album": "Album Name (if known)",
    "category": "which cultural category this matches"
  }
]

Make the songs authentic to the cultural categories and time period.
For "Disco beats of Bappi Lahiri" → include "I Am a Disco Dancer" by Bappi Lahiri

Respond only with valid JSON array.`;

    try {
      const llmService = new LLMService(userProfile);
      const response = await llmService.callLLMDirect(prompt);
      
      
      const jsonMatch = response.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        const songs = JSON.parse(jsonMatch[0]);
        return songs.map((song: any, index: number) => ({
          id: `cultural-${index}`,
          title: song.title || 'Unknown Song',
          artist: song.artist || 'Unknown Artist',
          album: song.album || 'Unknown Album',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
          spotifyUrl: undefined,
        }));
      }
    } catch (error) {
    }

    // Fallback to basic songs if LLM fails
    return getLocationAwareMusicFallbacks(context.location, context.year).slice(0, 5);
  };

  useEffect(() => {
    const generateCapsule = async () => {
      try {
        setError(null);
        setHasError(false);
        setProgress(10);
        
        // Extract location from life event or use provided location
        let extractedLocation = onboardingData.location || 'Unknown';
        
        // Try to extract location from life event text
        if (onboardingData.lifeEvent) {
          const locationMatch = onboardingData.lifeEvent.match(/in\s+([^,]+(?:,\s*[^,]+)*)/i);
          if (locationMatch) {
            extractedLocation = locationMatch[1].trim();
          }
        }
        
        console.log('🌍 Extracted Location:', extractedLocation);
        
        const llmService = new LLMService(userProfile);
        
        setCurrentStep('Analyzing your time period...');
        setProgress(20);
        
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        setCurrentStep('Calling LLM to generate cultural seeds...');
        
        const llmResponse = await llmService.generateCulturalSeeds(onboardingData);
        
        setCurrentStep('Getting Qloo recommendations...');
        
        setProgress(40);
        const qlooService = new QlooService(userProfile.qlooApiKey);
        const qlooRecommendations = await qlooService.getCrossDomainRecommendations(llmResponse.culturalSeeds);
        
        
        setCurrentStep('Generating playlist...');
        
        setProgress(60);
        
        // Use cultural music categories for playlist generation
        const musicCategories = llmResponse.culturalSeeds.music || [];
        const context = {
          year: onboardingData.year,
          location: extractedLocation,
          lifeEvent: onboardingData.lifeEvent || '',
          mood: onboardingData.mood
        };
        
        const playlist = await generatePlaylistFromCulturalCategories(musicCategories, context);
        
        setCurrentStep('Creating starter pack...');
        
        setProgress(80);
        
        // Generate starter pack items dynamically
        const starterPackCategories = ['fashion', 'food', 'travel', 'entertainment', 'lifestyle'];
        const starterPack: StarterPackItem[] = [];
        
        const generationContext = {
          year: onboardingData.year,
          location: extractedLocation,
          lifeEvent: onboardingData.lifeEvent || '',
          mood: onboardingData.mood,
          decade: onboardingData.decade
        };

        for (const category of starterPackCategories) {
          const item = await generateContextualContent(category, generationContext);
          
          starterPack.push({
            id: `${category}-${Date.now()}`,
            name: item.name,
            category: category as any,
            icon: item.icon,
            description: item.description
          });
        }
        
        setCurrentStep('Finalizing time capsule...');
        
        const timeCapsule: TimeCapsule = {
          id: Date.now().toString(),
          year: onboardingData.year,
          location: extractedLocation,
          mood: onboardingData.mood,
          lifeEvent: onboardingData.lifeEvent || '',
          playlist,
          starterPack,
          memoirSnippet: llmResponse.memoirSnippet,
          thenVsNow: llmResponse.thenVsNow,
          createdAt: new Date(),
          shareableCards: []
        };
        
        onComplete(timeCapsule);
        
      } catch (error) {
        console.error('Generation error:', error);
        setError(error instanceof Error ? error.message : 'Failed to generate time capsule');
        setHasError(true);
      }
    };

    generateCapsule();
  }, [onboardingData, userProfile]);

  // Helper function to get starter pack item name
  const getStarterPackItem = (recs: QlooRecommendation[], category: string, year: number, location: string): string => {
    // First priority: Use Qloo recommendation if available
    if (recs.length > 0) {
      return recs[0].name;
    }
    
    // Second priority: Use location-aware fallback
    const isIndia = location?.toLowerCase().includes('india') || 
                   ['delhi', 'mumbai', 'bangalore', 'chennai', 'kolkata', 'lucknow', 'pune', 'hyderabad'].some(city => 
                     location?.toLowerCase().includes(city.toLowerCase()));
    
    if (category === 'fashion') {
      if (isIndia) {
        if (year >= 2010) return 'Branded Jeans';
        if (year >= 2000) return 'Western Wear';
        if (year >= 1990) return 'Casual Shirts';
        if (year >= 1980) return 'Bell-bottom Pants';
        return 'Traditional Kurta';
      }
      // Global fallback
      if (year >= 2010) return 'Skinny Jeans';
      if (year >= 2000) return 'Low-Rise Jeans';
      if (year >= 1990) return 'Grunge Fashion';
      if (year >= 1980) return 'Acid Wash Denim';
      return 'Vintage T-Shirt';
    }
    
    if (category === 'food') {
      if (isIndia) {
        if (year >= 2010) return 'Café Coffee Day';
        if (year >= 2000) return 'Pizza Hut & McDonald\'s';
        if (year >= 1990) return 'Pepsi & Coca-Cola';
        if (year >= 1980) return 'Chai Culture';
        return 'Traditional Sweets';
      }
      // Global fallback
      if (year >= 2010) return 'Artisanal Coffee';
      if (year >= 2000) return 'Energy Drinks';
      if (year >= 1990) return 'Frappuccino';
      if (year >= 1980) return 'Diet Coke';
      return 'Soda Pop';
    }
    
    if (category === 'travel') {
      if (isIndia) {
        if (year >= 2010) return 'Metro Rail Networks';
        if (year >= 2000) return 'Shopping Malls';
        if (year >= 1990) return 'Cable TV Culture';
        if (year >= 1980) return 'Local Bazaars';
        return 'Traditional Markets';
      }
      // Global fallback
      if (year >= 2010) return 'Social Media Check-ins';
      if (year >= 2000) return 'Budget Travel';
      if (year >= 1990) return 'Cultural Festivals';
      if (year >= 1980) return 'Community Centers';
      return 'Road Trip Adventures';
    }
    
    return 'Cultural Item';
  };

  // Helper function to get starter pack icon
  const getStarterPackIcon = (category: string, year: number, location: string): string => {
    const isIndia = location?.toLowerCase().includes('india') || 
                   ['delhi', 'mumbai', 'bangalore', 'chennai', 'kolkata', 'lucknow', 'pune', 'hyderabad'].some(city => 
                     location?.toLowerCase().includes(city.toLowerCase()));
    
    if (category === 'fashion') {
      if (isIndia) {
        if (year >= 2010) return '👖';
        if (year >= 2000) return '👕';
        if (year >= 1990) return '👔';
        if (year >= 1980) return '👖';
        return '👘';
      }
      if (year >= 2010) return '👖';
      if (year >= 2000) return '👕';
      if (year >= 1990) return '🧥';
      if (year >= 1980) return '👔';
      return '👕';
    }
    
    if (category === 'food') {
      if (isIndia) {
        if (year >= 2010) return '☕';
        if (year >= 2000) return '🍕';
        if (year >= 1990) return '🥤';
        if (year >= 1980) return '🍵';
        return '🍬';
      }
      if (year >= 2010) return '☕';
      if (year >= 2000) return '🥤';
      if (year >= 1990) return '🍹';
      if (year >= 1980) return '🥤';
      return '🍕';
    }
    
    if (category === 'travel') {
      if (isIndia) {
        if (year >= 2010) return '🚇';
        if (year >= 2000) return '🏬';
        if (year >= 1990) return '📺';
        if (year >= 1980) return '🏪';
        return '🏛️';
      }
      if (year >= 2010) return '📸';
      if (year >= 2000) return '✈️';
      if (year >= 1990) return '🎒';
      if (year >= 1980) return '🏢';
      return '🚗';
    }
    
    return '🎯';
  };

  // Helper function to get starter pack description
  const getStarterPackDescription = (rec: QlooRecommendation | null, category: string, year: number, location: string): string => {
    // If we have Qloo data, use it
    if (rec) {
      return `${rec.name} was a defining cultural element of ${year}, representing the era's ${category} trends and lifestyle.`;
    }
    
    // Use location-aware descriptions for fallbacks
    const isIndia = location?.toLowerCase().includes('india') || 
                   ['delhi', 'mumbai', 'bangalore', 'chennai', 'kolkata', 'lucknow', 'pune', 'hyderabad'].some(city => 
                     location?.toLowerCase().includes(city.toLowerCase()));
    
    if (category === 'fashion') {
      if (isIndia) {
        if (year >= 2010) return 'Branded jeans became the symbol of India\'s growing urban youth culture and Western fashion adoption.';
        if (year >= 2000) return 'Western wear started gaining popularity in Indian metropolitan cities, marking a cultural shift.';
        if (year >= 1990) return 'Casual shirts represented the emerging middle-class professional identity in liberalizing India.';
        if (year >= 1980) return 'Bell-bottom pants were the trendy Western-inspired fashion choice for India\'s urban youth.';
        return 'Traditional kurta remained the cultural cornerstone of Indian formal and casual wear.';
      }
      // Global descriptions
      if (year >= 2010) return 'Skinny jeans became the universal denim choice, defining the sleek, fitted aesthetic of the 2010s.';
      if (year >= 2000) return 'Low-rise jeans epitomized early 2000s fashion, worn by celebrities and teens alike.';
      if (year >= 1990) return 'Grunge fashion became the anti-establishment uniform, symbolizing the rebellious spirit of the 90s.';
      if (year >= 1980) return 'Acid wash denim was the bold, experimental fabric treatment that screamed 80s excess.';
      return 'Vintage band t-shirts were the ultimate way to show your musical allegiance and countercultural cool.';
    }
    
    if (category === 'food') {
      if (isIndia) {
        if (year >= 2010) return 'Café Coffee Day became the symbol of India\'s growing coffee culture and youth hangout spaces.';
        if (year >= 2000) return 'Pizza Hut and McDonald\'s introduced Western fast food culture to Indian metropolitan cities.';
        if (year >= 1990) return 'Pepsi and Coca-Cola wars defined the cola generation and marked India\'s economic liberalization.';
        if (year >= 1980) return 'Chai culture was the social glue that brought people together across all walks of Indian life.';
        return 'Traditional sweets were the centerpiece of celebrations and cultural identity in Indian households.';
      }
      // Global descriptions
      if (year >= 2010) return 'Artisanal coffee culture exploded in the 2010s, turning daily caffeine into a craft experience.';
      if (year >= 2000) return 'Energy drinks became the fuel of choice for the always-on, digital generation of the 2000s.';
      if (year >= 1990) return 'Frappuccinos transformed coffee into dessert, perfectly capturing 90s indulgence and cafe culture.';
      if (year >= 1980) return 'Diet Coke launched the era of guilt-free indulgence, becoming the 80s power drink.';
      return 'Soda pop was the sweet escape that defined childhood and teenage social moments.';
    }
    
    if (category === 'travel') {
      if (isIndia) {
        if (year >= 2010) return 'Metro rail networks transformed urban mobility, connecting cities and enabling new lifestyle patterns.';
        if (year >= 2000) return 'Shopping malls emerged as new social spaces, introducing Western retail culture to Indian cities.';
        if (year >= 1990) return 'Cable TV culture brought global entertainment into Indian homes, changing viewing habits forever.';
        if (year >= 1980) return 'Local bazaars were the vibrant social and commercial hubs where communities gathered and traded.';
        return 'Traditional markets served as the cultural and economic heart of Indian communities.';
      }
      // Global descriptions
      if (year >= 2010) return 'Social media check-ins became the new travel currency, where experiences were measured in likes and shares.';
      if (year >= 2000) return 'Budget airlines democratized travel, making weekend getaways and gap years accessible to everyone.';
      if (year >= 1990) return 'Cultural festivals were the quintessential gathering spaces for community and artistic expression.';
      if (year >= 1980) return 'Community centers served as the social hubs where people gathered for events and activities.';
      return 'Road trip adventures embodied the freedom and discovery spirit of youth culture.';
    }
    
    return `This was a significant cultural element that defined the ${category} landscape of ${year}.`;
  };
  // Helper functions for starter pack generation
  const getFallbackFashion = (year: number): string => {
    if (year >= 2010) return 'Skinny Jeans';
    if (year >= 2000) return 'Low-Rise Jeans';
    if (year >= 1990) return 'Flannel Shirt';
    if (year >= 1980) return 'Acid Wash Denim';
    return 'Vintage T-Shirt';
  };

  const getFallbackFood = (year: number): string => {
    if (year >= 2010) return 'Artisanal Coffee';
    if (year >= 2000) return 'Energy Drinks';
    if (year >= 1990) return 'Frappuccino';
    if (year >= 1980) return 'Diet Coke';
    return 'Soda Pop';
  };

  const getFallbackTravel = (year: number): string => {
    if (year >= 2010) return 'Social Media Check-ins';
    if (year >= 2000) return 'Budget Travel';
    if (year >= 1990) return 'Cultural Festivals';
    if (year >= 1980) return 'Local Markets';
    return 'Community Gatherings';
  };

  const getLocationAwareTravel = (year: number, location: string): string => {
    const isIndia = location?.toLowerCase().includes('india') || 
                   ['delhi', 'mumbai', 'bangalore', 'chennai', 'kolkata', 'lucknow', 'pune', 'hyderabad'].some(city => 
                     location?.toLowerCase().includes(city.toLowerCase()));
    
    if (isIndia) {
      if (year >= 2010) return 'Metro Rail Networks';
      if (year >= 2000) return 'Shopping Malls';
      if (year >= 1990) return 'Cable TV Culture';
      if (year >= 1980) return 'Local Bazaars';
      return 'Traditional Markets';
    }
    
    // Western/Global context
    if (year >= 2010) return 'Instagram-worthy Destinations';
    if (year >= 2000) return 'Budget Airlines Travel';
    if (year >= 1990) return 'Backpacking Europe';
    if (year >= 1980) return 'Mall Culture';
    return 'Road Trip Adventures';
  };

  const getLocationAwareFashionIcon = (year: number, location: string): string => {
    const isIndia = location?.toLowerCase().includes('india') || 
                   ['delhi', 'mumbai', 'bangalore', 'chennai', 'kolkata', 'lucknow', 'pune', 'hyderabad'].some(city => 
                     location?.toLowerCase().includes(city.toLowerCase()));
    
    if (isIndia) {
      if (year >= 2010) return '👖';
      if (year >= 2000) return '👕';
      if (year >= 1990) return '👔';
      if (year >= 1980) return '👖';
      return '👘';
    }
    
    return getFashionIcon(year);
  };

  const getLocationAwareFoodIcon = (year: number, location: string): string => {
    const isIndia = location?.toLowerCase().includes('india') || 
                   ['delhi', 'mumbai', 'bangalore', 'chennai', 'kolkata', 'lucknow', 'pune', 'hyderabad'].some(city => 
                     location?.toLowerCase().includes(city.toLowerCase()));
    
    if (isIndia) {
      if (year >= 2010) return '☕';
      if (year >= 2000) return '🍕';
      if (year >= 1990) return '🥤';
      if (year >= 1980) return '🍵';
      return '🍬';
    }
    
    return getFoodIcon(year);
  };

  const getLocationAwareTravelIcon = (year: number, location: string): string => {
    const isIndia = location?.toLowerCase().includes('india') || 
                   ['delhi', 'mumbai', 'bangalore', 'chennai', 'kolkata', 'lucknow', 'pune', 'hyderabad'].some(city => 
                     location?.toLowerCase().includes(city.toLowerCase()));
    
    if (isIndia) {
      if (year >= 2010) return '🚇';
      if (year >= 2000) return '🏬';
      if (year >= 1990) return '📺';
      if (year >= 1980) return '🏪';
      return '🏛️';
    }
    
    return getTravelIcon(year);
  };

  const getLocationAwareFashionDescription = (rec: QlooRecommendation | null, year: number, location: string): string => {
    const isIndia = location?.toLowerCase().includes('india') || 
                   ['delhi', 'mumbai', 'bangalore', 'chennai', 'kolkata', 'lucknow', 'pune', 'hyderabad'].some(city => 
                     location?.toLowerCase().includes(city.toLowerCase()));
    
    if (rec) {
      return `${rec.name} was a defining fashion statement of ${year}, representing the era's style and cultural identity.`;
    }
    
    if (isIndia) {
      if (year >= 2010) return 'Branded jeans became the symbol of India\'s growing urban youth culture and Western fashion adoption.';
      if (year >= 2000) return 'Western wear started gaining popularity in Indian metropolitan cities, marking a cultural shift.';
      if (year >= 1990) return 'Casual shirts represented the emerging middle-class professional identity in liberalizing India.';
      if (year >= 1980) return 'Bell-bottom pants were the trendy Western-inspired fashion choice for India\'s urban youth.';
      return 'Traditional kurta remained the cultural cornerstone of Indian formal and casual wear.';
    }
    
    return getFashionDescription(rec, year);
  };

  const getLocationAwareFoodDescription = (rec: QlooRecommendation | null, year: number, location: string): string => {
    const isIndia = location?.toLowerCase().includes('india') || 
                   ['delhi', 'mumbai', 'bangalore', 'chennai', 'kolkata', 'lucknow', 'pune', 'hyderabad'].some(city => 
                     location?.toLowerCase().includes(city.toLowerCase()));
    
    if (rec) {
      return `${rec.name} captured the taste and dining culture of ${year}, becoming a memorable part of the era's lifestyle.`;
    }
    
    if (isIndia) {
      if (year >= 2010) return 'Café Coffee Day became the symbol of India\'s growing coffee culture and youth hangout spaces.';
      if (year >= 2000) return 'Pizza Hut and McDonald\'s introduced Western fast food culture to Indian metropolitan cities.';
      if (year >= 1990) return 'Pepsi and Coca-Cola wars defined the cola generation and marked India\'s economic liberalization.';
      if (year >= 1980) return 'Chai culture was the social glue that brought people together across all walks of Indian life.';
      return 'Traditional sweets were the centerpiece of celebrations and cultural identity in Indian households.';
    }
    
    return getFoodDescription(rec, year);
  };

  const getLocationAwareTravelDescription = (rec: QlooRecommendation | null, year: number, location: string): string => {
    const isIndia = location?.toLowerCase().includes('india') || 
                   ['delhi', 'mumbai', 'bangalore', 'chennai', 'kolkata', 'lucknow', 'pune', 'hyderabad'].some(city => 
                     location?.toLowerCase().includes(city.toLowerCase()));
    
    if (rec) {
      return `${rec.name} represented the travel and lifestyle aspirations that defined ${year}'s cultural zeitgeist.`;
    }
    
    if (isIndia) {
      if (year >= 2010) return 'Metro rail networks transformed urban mobility, connecting cities and enabling new lifestyle patterns.';
      if (year >= 2000) return 'Shopping malls emerged as new social spaces, introducing Western retail culture to Indian cities.';
      if (year >= 1990) return 'Cable TV culture brought global entertainment into Indian homes, changing viewing habits forever.';
      if (year >= 1980) return 'Local bazaars were the vibrant social and commercial hubs where communities gathered and traded.';
      return 'Traditional markets served as the cultural and economic heart of Indian communities.';
    }
    
    return getTravelDescription(rec, year);
  };

  // Universal location and era detection system
  const detectRegion = (location: string): string => {
    const loc = location.toLowerCase();
    
    // South Asia
    if (loc.includes('india') || ['delhi', 'mumbai', 'bangalore', 'chennai', 'kolkata', 'lucknow', 'pune', 'hyderabad'].some(city => loc.includes(city))) return 'south-asia';
    if (loc.includes('pakistan') || ['karachi', 'lahore', 'islamabad'].some(city => loc.includes(city))) return 'south-asia';
    if (loc.includes('bangladesh') || loc.includes('dhaka')) return 'south-asia';
    
    // East Asia
    if (loc.includes('japan') || ['tokyo', 'osaka', 'kyoto'].some(city => loc.includes(city))) return 'east-asia';
    if (loc.includes('china') || ['beijing', 'shanghai', 'guangzhou'].some(city => loc.includes(city))) return 'east-asia';
    if (loc.includes('korea') || ['seoul', 'busan'].some(city => loc.includes(city))) return 'east-asia';
    
    // Southeast Asia
    if (loc.includes('thailand') || loc.includes('bangkok')) return 'southeast-asia';
    if (loc.includes('singapore')) return 'southeast-asia';
    if (loc.includes('malaysia') || loc.includes('kuala lumpur')) return 'southeast-asia';
    if (loc.includes('indonesia') || loc.includes('jakarta')) return 'southeast-asia';
    
    // Europe
    if (loc.includes('uk') || loc.includes('britain') || ['london', 'manchester', 'birmingham'].some(city => loc.includes(city))) return 'europe';
    if (loc.includes('germany') || ['berlin', 'munich', 'hamburg'].some(city => loc.includes(city))) return 'europe';
    if (loc.includes('france') || ['paris', 'lyon', 'marseille'].some(city => loc.includes(city))) return 'europe';
    if (loc.includes('italy') || ['rome', 'milan', 'naples'].some(city => loc.includes(city))) return 'europe';
    if (loc.includes('spain') || ['madrid', 'barcelona', 'valencia'].some(city => loc.includes(city))) return 'europe';
    
    // North America
    if (loc.includes('usa') || loc.includes('america') || ['new york', 'los angeles', 'chicago', 'houston', 'phoenix'].some(city => loc.includes(city))) return 'north-america';
    if (loc.includes('canada') || ['toronto', 'vancouver', 'montreal'].some(city => loc.includes(city))) return 'north-america';
    
    // Latin America
    if (loc.includes('mexico') || loc.includes('mexico city')) return 'latin-america';
    if (loc.includes('brazil') || ['sao paulo', 'rio de janeiro'].some(city => loc.includes(city))) return 'latin-america';
    if (loc.includes('argentina') || loc.includes('buenos aires')) return 'latin-america';
    
    // Middle East
    if (loc.includes('uae') || loc.includes('dubai') || loc.includes('abu dhabi')) return 'middle-east';
    if (loc.includes('saudi') || loc.includes('riyadh')) return 'middle-east';
    if (loc.includes('israel') || loc.includes('tel aviv')) return 'middle-east';
    
    // Africa
    if (loc.includes('south africa') || ['cape town', 'johannesburg'].some(city => loc.includes(city))) return 'africa';
    if (loc.includes('nigeria') || loc.includes('lagos')) return 'africa';
    if (loc.includes('egypt') || loc.includes('cairo')) return 'africa';
    
    // Default to global/western
    return 'global';
  };

  // Universal cultural item generator
  const getUniversalCulturalItem = (category: 'fashion' | 'food' | 'travel', year: number, location: string, qlooRecs: QlooRecommendation[]): { name: string; icon: string; description: string } => {
    // First priority: Use Qloo recommendation if available
    if (qlooRecs.length > 0) {
      const rec = qlooRecs[0];
      return {
        name: rec.name,
        icon: getCategoryIcon(category, year, location),
        description: `${rec.name} was a defining ${category} element of ${year}, representing the era's cultural identity in ${location}.`
      };
    }

    // Second priority: Region and era-specific fallbacks
    const region = detectRegion(location);
    return getRegionalCulturalItem(category, year, region, location);
  };

  // Regional cultural items based on region and era
  const getRegionalCulturalItem = (category: 'fashion' | 'food' | 'travel', year: number, region: string, location: string): { name: string; icon: string; description: string } => {
    const culturalData: Record<string, Record<string, Record<string, { name: string; icon: string; description: string }[]>>> = {
      'south-asia': {
        fashion: {
          '1980s': [
            { name: 'Traditional Kurta', icon: '👘', description: 'Traditional kurta remained the cultural cornerstone of formal and casual wear in South Asia.' },
            { name: 'Bell-bottom Pants', icon: '👖', description: 'Bell-bottom pants were the trendy Western-inspired fashion choice for urban youth.' }
          ],
          '1990s': [
            { name: 'Casual Shirts', icon: '👔', description: 'Casual shirts represented the emerging middle-class professional identity.' },
            { name: 'Western Wear', icon: '👕', description: 'Western wear started gaining popularity in metropolitan cities.' }
          ],
          '2000s': [
            { name: 'Branded Jeans', icon: '👖', description: 'Branded jeans became the symbol of growing urban youth culture and Western fashion adoption.' }
          ]
        },
        food: {
          '1980s': [
            { name: 'Chai Culture', icon: '🍵', description: 'Chai culture was the social glue that brought people together across all walks of life.' },
            { name: 'Traditional Sweets', icon: '🍬', description: 'Traditional sweets were the centerpiece of celebrations and cultural identity.' }
          ],
          '1990s': [
            { name: 'Cola Wars', icon: '🥤', description: 'Pepsi and Coca-Cola wars defined the cola generation and marked economic liberalization.' }
          ],
          '2000s': [
            { name: 'Fast Food Chains', icon: '🍕', description: 'International fast food chains introduced Western dining culture to metropolitan cities.' }
          ]
        },
        travel: {
          '1980s': [
            { name: 'Local Bazaars', icon: '🏪', description: 'Local bazaars were the vibrant social and commercial hubs where communities gathered.' },
            { name: 'Traditional Markets', icon: '🏛️', description: 'Traditional markets served as the cultural and economic heart of communities.' }
          ],
          '1990s': [
            { name: 'Cable TV Culture', icon: '📺', description: 'Cable TV culture brought global entertainment into homes, changing viewing habits forever.' }
          ],
          '2000s': [
            { name: 'Shopping Malls', icon: '🏬', description: 'Shopping malls emerged as new social spaces, introducing Western retail culture.' }
          ]
        }
      },
      'east-asia': {
        fashion: {
          '1980s': [
            { name: 'Business Suits', icon: '👔', description: 'Business suits represented the economic boom and corporate culture of the 1980s.' }
          ],
          '1990s': [
            { name: 'Street Fashion', icon: '👕', description: 'Unique street fashion movements emerged, blending traditional and modern styles.' }
          ]
        },
        food: {
          '1980s': [
            { name: 'Instant Noodles', icon: '🍜', description: 'Instant noodles became a cultural phenomenon and convenience food staple.' }
          ],
          '1990s': [
            { name: 'Karaoke Culture', icon: '🎤', description: 'Karaoke culture transformed social dining and entertainment experiences.' }
          ]
        },
        travel: {
          '1980s': [
            { name: 'Department Stores', icon: '🏬', description: 'Department stores became the social and shopping centers of urban life.' }
          ]
        }
      },
      'europe': {
        fashion: {
          '1980s': [
            { name: 'Power Dressing', icon: '👔', description: 'Power dressing defined the ambitious, shoulder-padded aesthetic of 1980s Europe.' }
          ],
          '1990s': [
            { name: 'Minimalist Fashion', icon: '👕', description: 'Minimalist fashion emerged as a reaction to 80s excess, emphasizing clean lines.' }
          ]
        },
        food: {
          '1980s': [
            { name: 'Café Culture', icon: '☕', description: 'Café culture was the social foundation of European urban life and intellectual discourse.' }
          ],
          '1990s': [
            { name: 'Wine Bars', icon: '🍷', description: 'Wine bars became sophisticated social spaces for the emerging professional class.' }
          ]
        },
        travel: {
          '1980s': [
            { name: 'City Centers', icon: '🏛️', description: 'Historic city centers remained the cultural and social heart of European communities.' }
          ]
        }
      },
      'north-america': {
        fashion: {
          '1980s': [
            { name: 'Acid Wash Denim', icon: '👖', description: 'Acid wash denim was the bold, experimental fabric treatment that screamed 80s excess.' }
          ],
          '1990s': [
            { name: 'Grunge Fashion', icon: '🧥', description: 'Grunge fashion became the anti-establishment uniform, symbolizing rebellious spirit.' }
          ]
        },
        food: {
          '1980s': [
            { name: 'Diet Culture', icon: '🥤', description: 'Diet sodas launched the era of guilt-free indulgence and health consciousness.' }
          ],
          '1990s': [
            { name: 'Coffee Culture', icon: '☕', description: 'Specialty coffee culture exploded, turning daily caffeine into a lifestyle choice.' }
          ]
        },
        travel: {
          '1980s': [
            { name: 'Mall Culture', icon: '🏬', description: 'Shopping malls were the social epicenter where teens gathered and defined identity.' }
          ],
          '1990s': [
            { name: 'Alternative Venues', icon: '🎒', description: 'Alternative music venues and record stores became cultural gathering spaces.' }
          ]
        }
      },
      'global': {
        fashion: {
          '1980s': [
            { name: 'Bold Fashion', icon: '👔', description: 'Bold, expressive fashion defined the confident aesthetic of the 1980s.' }
          ],
          '1990s': [
            { name: 'Casual Wear', icon: '👕', description: 'Casual wear became mainstream as dress codes relaxed globally.' }
          ]
        },
        food: {
          '1980s': [
            { name: 'International Cuisine', icon: '🍽️', description: 'International cuisine became more accessible as global trade expanded.' }
          ]
        },
        travel: {
          '1980s': [
            { name: 'Urban Centers', icon: '🏢', description: 'Urban centers were the focal points of cultural and economic activity.' }
          ]
        }
      }
    };

    const decade = `${Math.floor(year / 10) * 10}s`;
    const regionData = culturalData[region] || culturalData['global'];
    const categoryData = regionData[category] || {};
    const eraData = categoryData[decade] || categoryData['1980s'] || [];
    
    if (eraData.length > 0) {
      return eraData[0];
    }

    // Ultimate fallback
    return {
      name: `Cultural ${category.charAt(0).toUpperCase() + category.slice(1)}`,
      icon: getCategoryIcon(category, year, location),
      description: `A significant ${category} element that defined the cultural landscape of ${year} in ${location}.`
    };
  };

  // Get appropriate icon for category
  const getCategoryIcon = (category: 'fashion' | 'food' | 'travel', year: number, location: string): string => {
    const iconMap = {
      fashion: ['👔', '👕', '👖', '👘', '🧥'],
      food: ['☕', '🍵', '🥤', '🍜', '🍕', '🍷', '🍬'],
      travel: ['🏪', '🏬', '🏛️', '📺', '🎒', '🏢', '🚇']
    };
    
    const icons = iconMap[category];
    return icons[Math.floor(Math.random() * icons.length)];
  };

  // Universal location-aware playlist generation
  const generateLocationAwarePlaylist = (musicRecs: QlooRecommendation[], year: number, location: string): PlaylistItem[] => {
    const playlist: PlaylistItem[] = [];
    
    // First priority: Use Qloo recommendations if available and era-appropriate
    if (musicRecs.length > 0) {
      for (const rec of musicRecs.slice(0, 3)) {
        // Check if the recommendation is era-appropriate
        if (!rec.metadata.year || rec.metadata.year <= year) {
          playlist.push({
            id: rec.id,
            title: rec.name || 'Unknown Track',
            artist: rec.metadata.artist || 'Unknown Artist',
            album: rec.metadata.album || 'Unknown Album',
            imageUrl: rec.metadata.imageUrl || getDefaultMusicImage(location),
            spotifyUrl: undefined,
          });
        }
      }
    }

    // Fill remaining slots with location and era-appropriate fallbacks
    while (playlist.length < 3) {
      const fallbackTrack = getLocationAwareMusicFallback(playlist.length, year, location);
      playlist.push(fallbackTrack);
    }

    return playlist;
  };

  // Get location and era-appropriate music fallbacks
  const getLocationAwareMusicFallback = (index: number, year: number, location: string): PlaylistItem => {
    const region = detectRegion(location);
    const decade = `${Math.floor(year / 10) * 10}s`;
    
    // Regional music database
    const regionalMusic: Record<string, Record<string, PlaylistItem[]>> = {
      'south-asia': {
        '1980s': [
          {
            id: 'sa-80s-1',
            title: 'Chura Liya Hai Tumne',
            artist: 'Asha Bhosle',
            album: 'Yaadon Ki Baaraat',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'sa-80s-2',
            title: 'Ek Do Teen',
            artist: 'Alka Yagnik',
            album: 'Tezaab',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'sa-80s-3',
            title: 'Mere Rang Mein Rangne Wali',
            artist: 'Mohammed Rafi',
            album: 'Maine Pyar Kiya',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
        ],
        '1990s': [
          {
            id: 'sa-90s-1',
            title: 'Dil To Pagal Hai',
            artist: 'Lata Mangeshkar',
            album: 'Dil To Pagal Hai',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'sa-90s-2',
            title: 'Tujhe Dekha To',
            artist: 'Kumar Sanu',
            album: 'Dilwale Dulhania Le Jayenge',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'sa-90s-3',
            title: 'Pehla Nasha',
            artist: 'Udit Narayan',
            album: 'Jo Jeeta Wohi Sikandar',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
        ],
      },
      'east-asia': {
        '1980s': [
          {
            id: 'ea-80s-1',
            title: 'Tsugaru Kaikyo Fuyugeshiki',
            artist: 'Ishikawa Sayuri',
            album: 'Enka Collection',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'ea-80s-2',
            title: 'Plastic Love',
            artist: 'Mariya Takeuchi',
            album: 'Variety',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'ea-80s-3',
            title: 'Stay With Me',
            artist: 'Miki Matsubara',
            album: 'Pocket Park',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
        ],
      },
      'europe': {
        '1980s': [
          {
            id: 'eu-80s-1',
            title: 'Blue Monday',
            artist: 'New Order',
            album: 'Power, Corruption & Lies',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'eu-80s-2',
            title: 'Sweet Dreams',
            artist: 'Eurythmics',
            album: 'Sweet Dreams',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'eu-80s-3',
            title: 'Tainted Love',
            artist: 'Soft Cell',
            album: 'Non-Stop Erotic Cabaret',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
        ],
      },
      'north-america': {
        '1980s': [
          {
            id: 'na-80s-1',
            title: 'Billie Jean',
            artist: 'Michael Jackson',
            album: 'Thriller',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'na-80s-2',
            title: 'Like a Virgin',
            artist: 'Madonna',
            album: 'Like a Virgin',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'na-80s-3',
            title: 'Eye of the Tiger',
            artist: 'Survivor',
            album: 'Eye of the Tiger',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
        ],
        '1990s': [
          {
            id: 'na-90s-1',
            title: 'Smells Like Teen Spirit',
            artist: 'Nirvana',
            album: 'Nevermind',
            imageUrl: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'na-90s-2',
            title: 'Creep',
            artist: 'Radiohead',
            album: 'Pablo Honey',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'na-90s-3',
            title: 'Wonderwall',
            artist: 'Oasis',
            album: '(What\'s the Story) Morning Glory?',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
        ],
      },
      'latin-america': {
        '1980s': [
          {
            id: 'la-80s-1',
            title: 'La Bamba',
            artist: 'Ritchie Valens',
            album: 'La Bamba',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'la-80s-2',
            title: 'Conga',
            artist: 'Miami Sound Machine',
            album: 'Primitive Love',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'la-80s-3',
            title: 'Bamboléo',
            artist: 'Gipsy Kings',
            album: 'Gipsy Kings',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
        ],
      },
      'africa': {
        '1980s': [
          {
            id: 'af-80s-1',
            title: 'Pata Pata',
            artist: 'Miriam Makeba',
            album: 'Pata Pata',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'af-80s-2',
            title: 'Zombie',
            artist: 'Fela Kuti',
            album: 'Zombie',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'af-80s-3',
            title: 'Graceland',
            artist: 'Paul Simon',
            album: 'Graceland',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
        ],
      },
    };

    // Get regional music for the era
    const regionData = regionalMusic[region] || regionalMusic['north-america'];
    const eraData = regionData[decade] || regionData['1980s'] || [];
    
    if (eraData.length > 0 && index < eraData.length) {
      return eraData[index];
    }

    // Ultimate fallback
    return {
      id: `fallback-${index}`,
      title: 'Cultural Song',
      artist: 'Local Artist',
      album: 'Cultural Collection',
      imageUrl: getDefaultMusicImage(location),
      spotifyUrl: undefined,
    };
  };

  // Get default music image based on location
  const getDefaultMusicImage = (location: string): string => {
    return 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400';
  };

  const getLocationAwareFood = (year: number, location: string): string => {
    const isIndia = location?.toLowerCase().includes('india') || 
                   ['delhi', 'mumbai', 'bangalore', 'chennai', 'kolkata', 'lucknow', 'pune', 'hyderabad'].some(city => 
                     location?.toLowerCase().includes(city.toLowerCase()));
    
    if (isIndia) {
      if (year >= 2010) return 'Café Coffee Day';
      if (year >= 2000) return 'Pizza Hut & McDonald\'s';
      if (year >= 1990) return 'Pepsi & Coca-Cola';
      if (year >= 1980) return 'Chai Culture';
      return 'Traditional Sweets';
    }
    
    return getFallbackFood(year);
  };

  const getLocationAwareFashion = (year: number, location: string): string => {
    const isIndia = location?.toLowerCase().includes('india') || 
                   ['delhi', 'mumbai', 'bangalore', 'chennai', 'kolkata', 'lucknow', 'pune', 'hyderabad'].some(city => 
                     location?.toLowerCase().includes(city.toLowerCase()));
    
    if (isIndia) {
      if (year >= 2010) return 'Branded Jeans';
      if (year >= 2000) return 'Western Wear';
      if (year >= 1990) return 'Casual Shirts';
      if (year >= 1980) return 'Bell-bottom Pants';
      return 'Traditional Kurta';
    }
    
    return getFallbackFashion(year);
  };

  const getFashionIcon = (year: number): string => {
    if (year >= 2010) return '👖';
    if (year >= 2000) return '👕';
    if (year >= 1990) return '🧥';
    if (year >= 1980) return '👔';
    return '👕';
  };

  const getFoodIcon = (year: number): string => {
    if (year >= 2010) return '☕';
    if (year >= 2000) return '🥤';
    if (year >= 1990) return '🍹';
    if (year >= 1980) return '🥤';
    return '🍕';
  };

  const getTravelIcon = (year: number): string => {
    if (year >= 2010) return '📸';
    if (year >= 2000) return '✈️';
    if (year >= 1990) return '🎒';
    if (year >= 1980) return '🏬';
    return '🚗';
  };

  const getFashionDescription = (rec: QlooRecommendation | null, year: number): string => {
    if (rec) {
      return `${rec.name} was a defining fashion statement of ${year}, representing the era's style and cultural identity.`;
    }
    
    if (year >= 2010) return 'Skinny jeans became the universal denim choice, defining the sleek, fitted aesthetic of the 2010s.';
    if (year >= 2000) return 'Low-rise jeans epitomized early 2000s fashion, worn by celebrities and teens alike.';
    if (year >= 1990) return 'Flannel shirts became the grunge uniform, symbolizing the anti-fashion rebellion of the 90s.';
    if (year >= 1980) return 'Acid wash denim was the bold, experimental fabric treatment that screamed 80s excess.';
    return 'Vintage band t-shirts were the ultimate way to show your musical allegiance and countercultural cool.';
  };

  const getTravelDescription = (rec: QlooRecommendation | null, year: number): string => {
    const location = onboardingData.location || '';
    const isIndia = location?.toLowerCase().includes('india') || 
                   ['delhi', 'mumbai', 'bangalore', 'chennai', 'kolkata', 'lucknow', 'pune', 'hyderabad'].some(city => 
                     location?.toLowerCase().includes(city.toLowerCase()));
    
    if (rec) {
      return `${rec.name} represented the travel and lifestyle aspirations that defined ${year}'s cultural zeitgeist.`;
    }
    
    if (isIndia) {
      if (year >= 2010) return 'Metro rail networks transformed urban mobility, connecting cities and enabling new lifestyle patterns.';
      if (year >= 2000) return 'Shopping malls emerged as new social spaces, introducing Western retail culture to Indian cities.';
      if (year >= 1990) return 'Cable TV culture brought global entertainment into Indian homes, changing viewing habits forever.';
      if (year >= 1980) return 'Local bazaars were the vibrant social and commercial hubs where communities gathered and traded.';
      return 'Traditional markets served as the cultural and economic heart of Indian communities.';
    }
    
    // Western/Global context
    if (year >= 2010) return 'Instagram-worthy destinations became the new travel currency, where experiences were measured in likes and shares.';
    if (year >= 2000) return 'Budget airlines democratized travel, making weekend getaways and gap years accessible to everyone.';
    if (year >= 1990) return 'Backpacking Europe was the quintessential coming-of-age adventure for 90s young adults.';
    if (year >= 1980) return 'Mall culture was the social epicenter where teens gathered, shopped, and defined their identity.';
    return 'Road trip adventures embodied the freedom and discovery spirit of youth culture.';
  };

  const getFoodDescription = (rec: QlooRecommendation | null, year: number): string => {
    const location = onboardingData.location || '';
    const isIndia = location?.toLowerCase().includes('india') || 
                   ['delhi', 'mumbai', 'bangalore', 'chennai', 'kolkata', 'lucknow', 'pune', 'hyderabad'].some(city => 
                     location?.toLowerCase().includes(city.toLowerCase()));
    
    if (rec) {
      return `${rec.name} captured the taste and dining culture of ${year}, becoming a memorable part of the era's lifestyle.`;
    }
    
    if (isIndia) {
      if (year >= 2010) return 'Café Coffee Day became the symbol of India\'s growing coffee culture and youth hangout spaces.';
      if (year >= 2000) return 'Pizza Hut and McDonald\'s introduced Western fast food culture to Indian metropolitan cities.';
      if (year >= 1990) return 'Pepsi and Coca-Cola wars defined the cola generation and marked India\'s economic liberalization.';
      if (year >= 1980) return 'Chai culture was the social glue that brought people together across all walks of Indian life.';
      return 'Traditional sweets were the centerpiece of celebrations and cultural identity in Indian households.';
    }
    
    // Western/Global context
    if (year >= 2010) return 'Artisanal coffee culture exploded in the 2010s, turning daily caffeine into a craft experience.';
    if (year >= 2000) return 'Energy drinks became the fuel of choice for the always-on, digital generation of the 2000s.';
    if (year >= 1990) return 'Frappuccinos transformed coffee into dessert, perfectly capturing 90s indulgence and cafe culture.';
    if (year >= 1980) return 'Diet Coke launched the era of guilt-free indulgence, becoming the 80s power drink.';
    return 'Soda pop was the sweet escape that defined childhood and teenage social moments.';
  };

  const generatePlaylist = async (
    culturalSeeds: { music: string[] },
    qlooRecommendations: { music: QlooRecommendation[] },
    onboardingData: OnboardingData,
    userProfile: UserProfile
  ): Promise<PlaylistItem[]> => {
    try {
      // Extract location from life event or use fallback
      const location = extractLocationFromContext(onboardingData);
      const yearOrDecade = onboardingData.decade; // Use decade for better API results
      
      console.log(`🎵 Generating playlist for: ${location}, ${yearOrDecade}`);
      
      // Try Qloo API first with location and era filters
      const qlooArtists = await fetchQlooArtists(location, yearOrDecade, userProfile.qlooApiKey!);
      
      if (qlooArtists.length > 0) {
        console.log(`✅ Qloo returned ${qlooArtists.length} artists:`, qlooArtists);
        return convertArtistsToPlaylist(qlooArtists, onboardingData.year);
      }
      
      // Fallback to LLM-generated culturally accurate playlist
      console.log(`⚠️ Qloo returned no results, using LLM fallback`);
      return generateLLMFallbackPlaylist(location, onboardingData.year, userProfile);
      
    } catch (error) {
      console.error('Playlist generation error:', error);
      // Final fallback to hardcoded culturally appropriate songs
      return generateHardcodedFallback(onboardingData);
    }
  };

  const extractLocationFromContext = (data: OnboardingData): string => {
    // Extract location from life event text
    if (data.lifeEvent) {
      const locationMatch = data.lifeEvent.match(/in\s+([^,]+(?:,\s*[^,]+)*)/i);
      if (locationMatch) {
        return locationMatch[1].trim();
      }
    }
    
    // Use provided location or default
    return data.location || 'India'; // Default based on common usage
  };

  const fetchQlooArtists = async (location: string, yearOrDecade: string, apiKey: string): Promise<any[]> => {
    try {
      const encodedLocation = encodeURIComponent(location);
      const eraTag = yearOrDecade.toLowerCase().replace('s', 's'); // e.g., "1980s"
      
      const url = `https://hackathon.api.qloo.com/v2/insights?filter.type=urn%3Aentity%3Aartist&signal.location.query=${encodedLocation}&signal.interests.tags=urn%3Atag%3Akeyword%3Aqloo%3A${eraTag}&take=3`;
      
      console.log(`🔍 Qloo API URL: ${url}`);
      
      const response = await fetch(url, {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
      });
      
      if (!response.ok) {
        console.error(`Qloo API error: ${response.status} ${response.statusText}`);
        return [];
      }
      
      const data = await response.json();
      console.log('🎵 Qloo API Response:', data);
      
      return data.results || [];
    } catch (error) {
      console.error('Qloo API fetch error:', error);
      return [];
    }
  };

  const convertArtistsToPlaylist = (artists: any[], year: number): PlaylistItem[] => {
    return artists.map((artist, index) => ({
      id: `qloo-${index}`,
      title: artist.name || 'Unknown Song',
      artist: artist.name || 'Unknown Artist',
      album: artist.metadata?.album || 'Unknown Album',
      imageUrl: artist.metadata?.image_url || 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
      spotifyUrl: undefined,
    }));
  };

  const generateLLMFallbackPlaylist = async (location: string, year: number, userProfile: UserProfile): Promise<PlaylistItem[]> => {
    try {
      const prompt = `Generate a JSON array of exactly 3 popular songs from ${year} that were culturally relevant in ${location}. 
      
      Focus on songs that were actually popular in ${location} during ${year}, not globally popular Western songs unless they were specifically popular in that region.
      
      Return only a JSON array in this format:
      [
        {
          "title": "Song Title",
          "artist": "Artist Name",
          "album": "Album Name"
        }
      ]`;
      
      const llmService = new LLMService(userProfile);
      const response = await llmService.callLLMDirect(prompt);
      
      const songs = JSON.parse(response);
      return songs.map((song: any, index: number) => ({
        id: `llm-${index}`,
        title: song.title,
        artist: song.artist,
        album: song.album || 'Unknown Album',
        imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
        spotifyUrl: undefined,
      }));
    } catch (error) {
      console.error('LLM fallback error:', error);
      return generateHardcodedFallback({ year, location } as OnboardingData);
    }
  };

  const generateHardcodedFallback = (data: OnboardingData): PlaylistItem[] => {
    const location = data.location || extractLocationFromContext(data);
    const year = data.year;
    
    // Location and era-specific fallbacks
    if (location.toLowerCase().includes('india') && year >= 1980 && year <= 1985) {
      return [
        {
          id: 'fallback-1',
          title: 'Chura Liya Hai Tumne',
          artist: 'Asha Bhosle',
          album: 'Yaadon Ki Baaraat',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
        },
        {
          id: 'fallback-2',
          title: 'Mere Rang Mein Rangne Wali',
          artist: 'Mohammed Rafi',
          album: 'Maine Pyar Kiya',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
        },
        {
          id: 'fallback-3',
          title: 'Tere Mere Sapne',
          artist: 'Kishore Kumar',
          album: 'Guide',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
        },
      ];
    }
    
    // Default global fallback for the era
    return [
      {
        id: 'fallback-1',
        title: 'Billie Jean',
        artist: 'Michael Jackson',
        album: 'Thriller',
        imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
      },
      {
        id: 'fallback-2',
        title: 'Like a Virgin',
        artist: 'Madonna',
        album: 'Like a Virgin',
        imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
      },
      {
        id: 'fallback-3',
        title: 'Eye of the Tiger',
        artist: 'Survivor',
        album: 'Eye of the Tiger',
        imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
      },
    ];
  };

  const generateStarterPack = (
    culturalSeeds: LLMResponse['culturalSeeds'],
    qlooRecommendations: any
  ): StarterPackItem[] => {
    const starterPack: StarterPackItem[] = [];
    
    // Fashion item
    const fashionRec = qlooRecommendations.fashion?.[0];
    starterPack.push({
      id: 'fashion-starter',
      name: fashionRec?.name || getLocationAwareFashion(onboardingData.year, onboardingData.location || ''),
      category: 'fashion',
      icon: getLocationAwareFashionIcon(onboardingData.year, onboardingData.location || ''),
      description: getLocationAwareFashionDescription(fashionRec, onboardingData.year, onboardingData.location || ''),
    });
    
    // Food item
    const foodRec = qlooRecommendations.food?.[0];
    starterPack.push({
      id: 'food-starter',
      name: foodRec?.name || getLocationAwareFood(onboardingData.year, onboardingData.location || ''),
      category: 'food',
      icon: getLocationAwareFoodIcon(onboardingData.year, onboardingData.location || ''),
      description: getLocationAwareFoodDescription(foodRec, onboardingData.year, onboardingData.location || ''),
    });
    
    // Travel/lifestyle item
    const travelRec = qlooRecommendations.travel?.[0];
    starterPack.push({
      id: 'travel-starter',
      name: travelRec?.name || getLocationAwareTravel(onboardingData.year, onboardingData.location || ''),
      category: 'travel',
      icon: getLocationAwareTravelIcon(onboardingData.year, onboardingData.location || ''),
      description: getLocationAwareTravelDescription(travelRec, onboardingData.year, onboardingData.location || ''),
    });
    
    return starterPack;
  };

  const isCulturallyRelevant = (item: any, location: string, year: number): boolean => {
    const artist = item.metadata?.artist || item.name || '';
    const songYear = item.metadata?.year || year;
    const region = getRegionFromLocation(location);
    
    // Era relevance check (within 5 years of target year)
    if (Math.abs(songYear - year) > 5) {
      return false;
    }
    
    // Regional cultural relevance check
    return isMusicCulturallyRelevant(artist, region, year);
  };

  const isMusicCulturallyRelevant = (artist: string, region: string, year: number): boolean => {
    const artistLower = artist.toLowerCase();
    
    // Global artists that were popular worldwide
    const globalArtists1980s = ['abba', 'bee gees', 'elvis presley', 'beatles'];
    const globalArtists1990s = ['michael jackson', 'madonna', 'whitney houston', 'celine dion'];
    
    if (region === 'south_asia') {
      // Indian subcontinent music preferences
      const indianArtists = [
        'lata mangeshkar', 'kishore kumar', 'mohammed rafi', 'asha bhosle',
        'r.d. burman', 'ilaiyaraaja', 'a.r. rahman', 'usha uthup'
      ];
      
      if (indianArtists.some(name => artistLower.includes(name))) return true;
      
      // Western artists popular in India by era
      if (year <= 1985) {
        return globalArtists1980s.some(name => artistLower.includes(name));
      } else if (year <= 1995) {
        return [...globalArtists1980s, ...globalArtists1990s].some(name => artistLower.includes(name));
      }
      
      return false;
    }
    
    if (region === 'east_asia') {
      const asianArtists = [
        'mariya takeuchi', 'tatsuro yamashita', 'anri', 'junko ohashi',
        'teresa teng', 'beyond', 'faye wong'
      ];
      
      if (asianArtists.some(name => artistLower.includes(name))) return true;
      
      // Western influence came later in East Asia
      if (year >= 1985) {
        return [...globalArtists1980s, ...globalArtists1990s].some(name => artistLower.includes(name));
      }
      
      return false;
    }
    
    if (region === 'europe') {
      const europeanArtists = [
        'new order', 'depeche mode', 'eurythmics', 'duran duran',
        'kraftwerk', 'abba', 'roxette', 'ace of base'
      ];
      
      if (europeanArtists.some(name => artistLower.includes(name))) return true;
      return [...globalArtists1980s, ...globalArtists1990s].some(name => artistLower.includes(name));
    }
    
    if (region === 'north_america') {
      // Most Western artists are relevant for North America
      return true;
    }
    
    if (region === 'latin_america') {
      const latinArtists = [
        'selena', 'mana', 'luis miguel', 'gloria estefan',
        'juan gabriel', 'rocio durcal', 'jose jose'
      ];
      
      if (latinArtists.some(name => artistLower.includes(name))) return true;
      
      // Global artists popular in Latin America
      if (year >= 1980) {
        return [...globalArtists1980s, ...globalArtists1990s].some(name => artistLower.includes(name));
      }
    }
    
    if (region === 'africa') {
      const africanArtists = [
        'fela kuti', 'king sunny ade', 'miriam makeba', 'hugh masekela',
        'youssou n\'dour', 'salif keita', 'ali farka toure'
      ];
      
      if (africanArtists.some(name => artistLower.includes(name))) return true;
      
      // Limited Western influence in early periods
      if (year >= 1990) {
        return globalArtists1990s.some(name => artistLower.includes(name));
      }
    }
    
    // Default: allow global artists for other regions
    return [...globalArtists1980s, ...globalArtists1990s].some(name => artistLower.includes(name));
  };

  const getRegionalMusicFallbacks = (location: string, year: number): PlaylistItem[] => {
    const region = getRegionFromLocation(location);
    
    const fallbacks: Record<string, PlaylistItem[]> = {
      south_asia: [
        {
          id: 'indian-1',
          title: 'Chura Liya Hai Tumne',
          artist: 'Asha Bhosle',
          album: 'Yaadon Ki Baaraat',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
        },
        {
          id: 'indian-2',
          title: 'Ek Do Teen',
          artist: 'Alka Yagnik',
          album: 'Tezaab',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
        },
        {
          id: 'indian-3',
          title: 'Mere Rang Mein Rangne Wali',
          artist: 'Mohammed Rafi',
          album: 'Maine Pyar Kiya',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
        },
        {
          id: 'indian-4',
          title: 'Tere Mere Sapne',
          artist: 'Kishore Kumar',
          album: 'Guide',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
        },
        {
          id: 'indian-5',
          title: 'Lag Jaa Gale',
          artist: 'Lata Mangeshkar',
          album: 'Woh Kaun Thi',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
        },
      ],
      east_asia: [
        {
          id: 'asian-1',
          title: 'Plastic Love',
          artist: 'Mariya Takeuchi',
          album: 'Variety',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
        },
        {
          id: 'asian-2',
          title: 'Ride on Time',
          artist: 'Tatsuro Yamashita',
          album: 'Ride on Time',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
        },
      ],
      europe: [
        {
          id: 'euro-1',
          title: 'Blue Monday',
          artist: 'New Order',
          album: 'Power, Corruption & Lies',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
        },
        {
          id: 'euro-2',
          title: 'Sweet Dreams',
          artist: 'Eurythmics',
          album: 'Sweet Dreams',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
        },
      ],
      north_america: [
        {
          id: 'na-1',
          title: 'Billie Jean',
          artist: 'Michael Jackson',
          album: 'Thriller',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
        },
        {
          id: 'na-2',
          title: 'Like a Virgin',
          artist: 'Madonna',
          album: 'Like a Virgin',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
        },
      ],
      latin_america: [
        {
          id: 'latin-1',
          title: 'La Bamba',
          artist: 'Ritchie Valens',
          album: 'La Bamba',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
        },
        {
          id: 'latin-2',
          title: 'Conga',
          artist: 'Gloria Estefan',
          album: 'Primitive Love',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
        },
      ],
      africa: [
        {
          id: 'african-1',
          title: 'Water No Get Enemy',
          artist: 'Fela Kuti',
          album: 'Expensive Shit',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
        },
        {
          id: 'african-2',
          title: 'Pata Pata',
          artist: 'Miriam Makeba',
          album: 'Pata Pata',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
        },
      ],
    };
    
    return fallbacks[region] || fallbacks.north_america;
  };

  const getRegionFromLocation = (location: string): string => {
    const loc = location.toLowerCase();
    
    // South Asia
    if (loc.includes('india') || ['delhi', 'mumbai', 'bangalore', 'chennai', 'kolkata', 'lucknow', 'pune', 'hyderabad'].some(city => loc.includes(city))) return 'south_asia';
    if (loc.includes('pakistan') || ['karachi', 'lahore', 'islamabad'].some(city => loc.includes(city))) return 'south_asia';
    if (loc.includes('bangladesh') || loc.includes('dhaka')) return 'south_asia';
    
    // East Asia
    if (loc.includes('japan') || ['tokyo', 'osaka', 'kyoto'].some(city => loc.includes(city))) return 'east_asia';
    if (loc.includes('china') || ['beijing', 'shanghai', 'guangzhou'].some(city => loc.includes(city))) return 'east_asia';
    if (loc.includes('korea') || ['seoul', 'busan'].some(city => loc.includes(city))) return 'east_asia';
    
    // Southeast Asia
    if (loc.includes('thailand') || loc.includes('bangkok')) return 'southeast_asia';
    if (loc.includes('singapore')) return 'southeast_asia';
    if (loc.includes('malaysia') || loc.includes('kuala lumpur')) return 'southeast_asia';
    if (loc.includes('indonesia') || loc.includes('jakarta')) return 'southeast_asia';
    
    // Europe
    if (loc.includes('uk') || loc.includes('britain') || ['london', 'manchester', 'birmingham'].some(city => loc.includes(city))) return 'europe';
    if (loc.includes('germany') || ['berlin', 'munich', 'hamburg'].some(city => loc.includes(city))) return 'europe';
    if (loc.includes('france') || ['paris', 'lyon', 'marseille'].some(city => loc.includes(city))) return 'europe';
    if (loc.includes('italy') || ['rome', 'milan', 'naples'].some(city => loc.includes(city))) return 'europe';
    if (loc.includes('spain') || ['madrid', 'barcelona', 'valencia'].some(city => loc.includes(city))) return 'europe';
    
    // North America
    if (loc.includes('usa') || loc.includes('america') || ['new york', 'los angeles', 'chicago', 'houston', 'phoenix'].some(city => loc.includes(city))) return 'north_america';
    if (loc.includes('canada') || ['toronto', 'vancouver', 'montreal'].some(city => loc.includes(city))) return 'north_america';
    
    // Latin America
    if (loc.includes('mexico') || loc.includes('mexico city')) return 'latin_america';
    if (loc.includes('brazil') || ['sao paulo', 'rio de janeiro'].some(city => loc.includes(city))) return 'latin_america';
    if (loc.includes('argentina') || loc.includes('buenos aires')) return 'latin_america';
    
    // Middle East
    if (loc.includes('uae') || loc.includes('dubai') || loc.includes('abu dhabi')) return 'middle_east';
    if (loc.includes('saudi') || loc.includes('riyadh')) return 'middle_east';
    if (loc.includes('israel') || loc.includes('tel aviv')) return 'middle_east';
    
    // Africa
    if (loc.includes('south africa') || ['cape town', 'johannesburg'].some(city => loc.includes(city))) return 'africa';
    if (loc.includes('nigeria') || loc.includes('lagos')) return 'africa';
    if (loc.includes('egypt') || loc.includes('cairo')) return 'africa';
    
    // Default to global/western
    return 'north_america';
  };

  const isIndianArtist = (artist: string): boolean => {
    const indianArtists = ['lata mangeshkar', 'kishore kumar', 'mohammed rafi', 'asha bhosle', 'alka yagnik', 'udit narayan', 'kumar sanu', 'sonu nigam'];
    return indianArtists.some(name => artist.includes(name));
  };

  const isGloballyPopularInIndia = (artist: string, year: number): boolean => {
    // Western artists that were actually popular in India during specific periods
    if (year >= 1980 && year <= 1985) {
      return ['abba', 'bee gees', 'elvis presley'].some(name => artist.includes(name));
    }
    if (year >= 1985 && year <= 1990) {
      return ['michael jackson', 'madonna', 'george michael'].some(name => artist.includes(name));
    }
    return false;
  };

  const isEastAsianArtist = (artist: string): boolean => {
    const eastAsianArtists = ['mariya takeuchi', 'tatsuro yamashita', 'anri', 'junko ohashi', 'teresa teng'];
    return eastAsianArtists.some(name => artist.includes(name));
  };

  const isGloballyPopularInEastAsia = (artist: string, year: number): boolean => {
    if (year >= 1980 && year <= 1990) {
      return ['michael jackson', 'madonna', 'duran duran', 'wham!'].some(name => artist.includes(name));
    }
    return false;
  };

  const isSoutheastAsianArtist = (artist: string): boolean => {
    const southeastAsianArtists = ['siti nurhaliza', 'krisdayanti', 'agnes monica'];
    return southeastAsianArtists.some(name => artist.includes(name));
  };

  const isGloballyPopularInSoutheastAsia = (artist: string, year: number): boolean => {
    if (year >= 1980 && year <= 1990) {
      return ['michael jackson', 'madonna', 'lionel richie'].some(name => artist.includes(name));
    }
    return false;
  };

  const isEuropeanArtist = (artist: string): boolean => {
    const europeanArtists = ['abba', 'duran duran', 'depeche mode', 'new order', 'pet shop boys'];
    return europeanArtists.some(name => artist.includes(name));
  };

  const isGloballyPopularInEurope = (artist: string, year: number): boolean => {
    return true; // Europe had broad global music access
  };

  const isNorthAmericanArtist = (artist: string): boolean => {
    const northAmericanArtists = ['michael jackson', 'madonna', 'prince', 'whitney houston', 'bruce springsteen'];
    return northAmericanArtists.some(name => artist.includes(name));
  };

  const isGloballyPopularInNorthAmerica = (artist: string, year: number): boolean => {
    return true; // North America had broad global music access
  };

  const isLatinAmericanArtist = (artist: string): boolean => {
    const latinAmericanArtists = ['selena', 'mana', 'luis miguel', 'gloria estefan'];
    return latinAmericanArtists.some(name => artist.includes(name));
  };

  const isGloballyPopularInLatinAmerica = (artist: string, year: number): boolean => {
    if (year >= 1980 && year <= 1990) {
      return ['michael jackson', 'madonna', 'lionel richie'].some(name => artist.includes(name));
    }
    return false;
  };

  const isMiddleEasternArtist = (artist: string): boolean => {
    const middleEasternArtists = ['fairuz', 'umm kulthum', 'mohamed abdel wahab'];
    return middleEasternArtists.some(name => artist.includes(name));
  };

  const isGloballyPopularInMiddleEast = (artist: string, year: number): boolean => {
    if (year >= 1980 && year <= 1990) {
      return ['michael jackson', 'madonna'].some(name => artist.includes(name));
    }
    return false;
  };

  const isAfricanArtist = (artist: string): boolean => {
    const africanArtists = ['fela kuti', 'king sunny ade', 'youssou ndour', 'salif keita'];
    return africanArtists.some(name => artist.includes(name));
  };

  const isGloballyPopularInAfrica = (artist: string, year: number): boolean => {
    if (year >= 1980 && year <= 1990) {
      return ['michael jackson', 'bob marley', 'lionel richie'].some(name => artist.includes(name));
    }
    return false;
  };

  const getLocationAwareMusic = (location: string = '', year: number): PlaylistItem[] => {
    const region = detectRegion(location);
    
    const regionalMusic: Record<string, PlaylistItem[]> = {
      'south-asia': [
        {
          id: 'indian-1',
          title: 'Chura Liya Hai Tumne',
          artist: 'Asha Bhosle',
          album: 'Yaadon Ki Baaraat',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
          spotifyUrl: '',
        },
        {
          id: 'indian-2',
          title: 'Ek Do Teen',
          artist: 'Alka Yagnik',
          album: 'Tezaab',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
          spotifyUrl: '',
        },
        {
          id: 'indian-3',
          title: 'Mere Rang Mein Rangne Wali',
          artist: 'Mohammed Rafi',
          album: 'Maine Pyar Kiya',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
          spotifyUrl: '',
        },
        {
          id: 'indian-4',
          title: 'Tere Mere Sapne',
          artist: 'Kishore Kumar',
          album: 'Guide',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
          spotifyUrl: '',
        },
        {
          id: 'indian-5',
          title: 'Lag Jaa Gale',
          artist: 'Lata Mangeshkar',
          album: 'Woh Kaun Thi',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
          spotifyUrl: '',
        },
      ],
      'east-asia': [
        {
          id: 'eastasia-1',
          title: 'Plastic Love',
          artist: 'Mariya Takeuchi',
          album: 'Variety',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
          spotifyUrl: '',
        },
        {
          id: 'eastasia-2',
          title: 'Ride on Time',
          artist: 'Tatsuro Yamashita',
          album: 'Ride on Time',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
          spotifyUrl: '',
        },
      ],
      'europe': [
        {
          id: 'europe-1',
          title: 'Blue Monday',
          artist: 'New Order',
          album: 'Power, Corruption & Lies',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
          spotifyUrl: '',
        },
        {
          id: 'europe-2',
          title: 'Sweet Dreams',
          artist: 'Eurythmics',
          album: 'Sweet Dreams',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
          spotifyUrl: '',
        },
      ],
      'north-america': [
        {
          id: 'northamerica-1',
          title: 'Billie Jean',
          artist: 'Michael Jackson',
          album: 'Thriller',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
          spotifyUrl: '',
        },
        {
          id: 'northamerica-2',
          title: 'Like a Virgin',
          artist: 'Madonna',
          album: 'Like a Virgin',
          imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
          spotifyUrl: '',
        },
      ],
    };
    
    return regionalMusic[region] || regionalMusic['north-america'];
  };

  const getLocationAwareMusicFallbacks = (location: string, year: number): PlaylistItem[] => {
    const region = detectRegion(location);
    const decade = `${Math.floor(year / 10) * 10}s`;
    
    // Regional music database
    const regionalMusic: Record<string, Record<string, PlaylistItem[]>> = {
      'south-asia': {
        '1980s': [
          {
            id: 'sa-80s-1',
            title: 'Chura Liya Hai Tumne',
            artist: 'Asha Bhosle',
            album: 'Yaadon Ki Baaraat',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'sa-80s-2',
            title: 'Ek Do Teen',
            artist: 'Alka Yagnik',
            album: 'Tezaab',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'sa-80s-3',
            title: 'Mere Rang Mein Rangne Wali',
            artist: 'Mohammed Rafi',
            album: 'Maine Pyar Kiya',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'sa-80s-4',
            title: 'Tere Mere Sapne',
            artist: 'Kishore Kumar',
            album: 'Guide',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'sa-80s-5',
            title: 'Lag Jaa Gale',
            artist: 'Lata Mangeshkar',
            album: 'Woh Kaun Thi',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
        ],
        '1990s': [
          {
            id: 'sa-90s-1',
            title: 'Dil To Pagal Hai',
            artist: 'Lata Mangeshkar',
            album: 'Dil To Pagal Hai',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'sa-90s-2',
            title: 'Tujhe Dekha To',
            artist: 'Kumar Sanu',
            album: 'Dilwale Dulhania Le Jayenge',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'sa-90s-3',
            title: 'Pehla Nasha',
            artist: 'Udit Narayan',
            album: 'Jo Jeeta Wohi Sikandar',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'sa-90s-4',
            title: 'Kuch Kuch Hota Hai',
            artist: 'Alka Yagnik',
            album: 'Kuch Kuch Hota Hai',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'sa-90s-5',
            title: 'Kal Ho Naa Ho',
            artist: 'Sonu Nigam',
            album: 'Kal Ho Naa Ho',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
        ],
      },
      'east-asia': {
        '1980s': [
          {
            id: 'ea-80s-1',
            title: 'Plastic Love',
            artist: 'Mariya Takeuchi',
            album: 'Variety',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'ea-80s-2',
            title: 'Stay With Me',
            artist: 'Miki Matsubara',
            album: 'Pocket Park',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'ea-80s-3',
            title: 'Ride on Time',
            artist: 'Tatsuro Yamashita',
            album: 'Ride on Time',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'ea-80s-4',
            title: 'Anri - Last Summer Whisper',
            artist: 'Anri',
            album: 'Timely!!',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'ea-80s-5',
            title: 'Telephone Number',
            artist: 'Junko Ohashi',
            album: 'Magical',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
        ],
      },
      'europe': {
        '1980s': [
          {
            id: 'eu-80s-1',
            title: 'Blue Monday',
            artist: 'New Order',
            album: 'Power, Corruption & Lies',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'eu-80s-2',
            title: 'Sweet Dreams',
            artist: 'Eurythmics',
            album: 'Sweet Dreams',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'eu-80s-3',
            title: 'Tainted Love',
            artist: 'Soft Cell',
            album: 'Non-Stop Erotic Cabaret',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'eu-80s-4',
            title: 'Personal Jesus',
            artist: 'Depeche Mode',
            album: 'Violator',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'eu-80s-5',
            title: 'Hungry Like the Wolf',
            artist: 'Duran Duran',
            album: 'Rio',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
        ],
      },
      'north-america': {
        '1980s': [
          {
            id: 'na-80s-1',
            title: 'Billie Jean',
            artist: 'Michael Jackson',
            album: 'Thriller',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'na-80s-2',
            title: 'Like a Virgin',
            artist: 'Madonna',
            album: 'Like a Virgin',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'na-80s-3',
            title: 'Eye of the Tiger',
            artist: 'Survivor',
            album: 'Eye of the Tiger',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'na-80s-4',
            title: 'Purple Rain',
            artist: 'Prince',
            album: 'Purple Rain',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'na-80s-5',
            title: 'I Wanna Dance with Somebody',
            artist: 'Whitney Houston',
            album: 'Whitney',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
        ],
        '1990s': [
          {
            id: 'na-90s-1',
            title: 'Smells Like Teen Spirit',
            artist: 'Nirvana',
            album: 'Nevermind',
            imageUrl: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'na-90s-2',
            title: 'Creep',
            artist: 'Radiohead',
            album: 'Pablo Honey',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'na-90s-3',
            title: 'Wonderwall',
            artist: 'Oasis',
            album: '(What\'s the Story) Morning Glory?',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'na-90s-4',
            title: 'Black',
            artist: 'Pearl Jam',
            album: 'Ten',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
          {
            id: 'na-90s-5',
            title: 'Losing My Religion',
            artist: 'R.E.M.',
            album: 'Out of Time',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
            spotifyUrl: undefined,
          },
        ],
      },
    };

    // Get regional music for the era
    const regionData = regionalMusic[region] || regionalMusic['north-america'];
    const eraData = regionData[decade] || regionData['1980s'] || [];
    
    return eraData.length > 0 ? eraData : getFallbackMusic();
  };

  const getFallbackMusic = (): PlaylistItem[] => {
    return [
      {
        id: 'fallback-1',
        title: 'Billie Jean',
        artist: 'Michael Jackson',
        album: 'Thriller',
        imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
        spotifyUrl: '',
      },
      {
        id: 'fallback-2',
        title: 'Like a Virgin',
        artist: 'Madonna',
        album: 'Like a Virgin',
        imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
        spotifyUrl: '',
      },
      {
        id: 'fallback-3',
        title: 'Sweet Dreams',
        artist: 'Eurythmics',
        album: 'Sweet Dreams',
        imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
        spotifyUrl: '',
      },
      {
        id: 'fallback-4',
        title: 'Blue Monday',
        artist: 'New Order',
        album: 'Power, Corruption & Lies',
        imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
        spotifyUrl: '',
      },
      {
        id: 'fallback-5',
        title: 'Tainted Love',
        artist: 'Soft Cell',
        album: 'Non-Stop Erotic Cabaret',
        imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
        spotifyUrl: '',
      },
    ];
  };

  const steps = [
    'Analyzing your time period...',
    'Calling LLM to generate cultural seeds...',
    'Fetching music recommendations from Qloo...',
    'Getting movie and fashion suggestions...',
    'Curating food and technology items...',
    'Composing memoir snippet...',
    'Creating then vs. now comparisons...',
    'Finalizing your time capsule...'
  ];

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 z-50 flex items-center justify-center p-4">
      <div className="bg-white/10 backdrop-blur-lg rounded-3xl shadow-2xl max-w-lg w-full p-8 text-center">
        <div className="mb-8">
          {stage === 'processing' && (
            <>
              <Brain className="w-16 h-16 text-yellow-400 mx-auto mb-4 animate-pulse" />
              <h2 className="text-2xl font-bold text-white mb-2">Processing Your Memories</h2>
              <p className="text-blue-200">Our AI is analyzing your {onboardingData.decade} experience...</p>
            </>
          )}
          
          {stage === 'generating' && (
            <>
              <Sparkles className="w-16 h-16 text-pink-400 mx-auto mb-4 animate-spin" />
              <h2 className="text-2xl font-bold text-white mb-2">Generating Your Time Capsule</h2>
              <p className="text-blue-200">Curating the perfect cultural mix...</p>
            </>
          )}
          
          {stage === 'complete' && (
            <>
              <Clock className="w-16 h-16 text-green-400 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-white mb-2">Time Capsule Ready!</h2>
              <p className="text-blue-200">Your {onboardingData.year} memories have been captured</p>
            </>
          )}
        </div>

        {/* Show error state */}
        {error && hasError && (
          <div className="mt-6 p-4 bg-red-500/20 border border-red-400 rounded-xl">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-red-400 text-xl">⚠️</span>
              <h3 className="text-lg font-semibold text-red-200">Generation Error</h3>
            </div>
            <p className="text-red-200 text-sm mb-4">{error}</p>
            <div className="flex gap-3">
              <button
                onClick={() => {
                  setHasError(false);
                  setError(null);
                  setProgress(0);
                  setCurrentStep('');
                  // Restart generation
                  window.location.reload();
                }}
                className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors text-sm"
              >
                Try Again
              </button>
              <button
                onClick={onCancel}
                className="px-4 py-2 bg-white/20 text-white rounded-lg hover:bg-white/30 transition-colors text-sm"
              >
                Go Back
              </button>
            </div>
          </div>
        )}

        {/* Progress Bar */}
        {!hasError && (
          <div className="mb-6">
          <div className="bg-white/20 rounded-full h-3 mb-2">
            <div 
              className="bg-gradient-to-r from-yellow-400 to-pink-400 h-3 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="text-sm text-blue-200">{Math.round(progress)}% complete</p>
        </div>
        )}

        {/* Current Step */}
        {stage === 'processing' && !hasError && (
          <div className="flex items-center justify-center gap-3 text-white">
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>{currentStep}</span>
          </div>
        )}

        {/* Cancel Button */}
        {!hasError && (
          <button
            onClick={onCancel}
            className="mt-6 px-6 py-2 text-white/70 hover:text-white transition-colors"
          >
            Cancel
          </button>
        )}
      </div>
    </div>
  );
};

export default TimeCapsuleGenerator;