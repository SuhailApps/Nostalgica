import React from 'react';
import { Clock, Heart, Share2, Settings, User, Archive } from 'lucide-react';

interface GlobalHeaderProps {
  currentView: string;
  userProfile?: any;
  savedCapsulesCount: number;
  onNavigate: (view: string) => void;
}

const GlobalHeader: React.FC<GlobalHeaderProps> = ({
  currentView,
  userProfile,
  savedCapsulesCount,
  onNavigate
}) => {
  return (
    <header className="bg-gradient-to-r from-purple-900/90 via-blue-900/90 to-indigo-900/90 backdrop-blur-sm text-white shadow-2xl sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          {/* Logo and Brand */}
          <div className="flex items-center space-x-3">
            <button 
              onClick={() => onNavigate('landing')}
              className="flex items-center space-x-3 hover:opacity-80 transition-opacity"
            >
              <div className="relative">
                <Clock className="w-8 h-8 text-yellow-400" />
                <div className="absolute inset-0 animate-pulse bg-yellow-400/20 rounded-full"></div>
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-yellow-400 to-pink-400 bg-clip-text text-transparent">
                  Nostalgia Engine
                </h1>
                <p className="text-sm text-gray-300 hidden sm:block">Rewind your cultural memories</p>
              </div>
            </button>
          </div>
          
          {/* Main Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <button
              onClick={() => onNavigate('landing')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                currentView === 'landing' 
                  ? 'bg-white/20 text-white' 
                  : 'text-gray-300 hover:text-white hover:bg-white/10'
              }`}
            >
              Home
            </button>
            
            {savedCapsulesCount > 0 && (
              <button
                onClick={() => onNavigate('library')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                  currentView === 'library' 
                    ? 'bg-white/20 text-white' 
                    : 'text-gray-300 hover:text-white hover:bg-white/10'
                }`}
              >
                <Archive className="w-4 h-4" />
                My Capsules
                <span className="bg-yellow-400 text-purple-900 text-xs rounded-full w-5 h-5 flex items-center justify-center font-semibold">
                  {savedCapsulesCount}
                </span>
              </button>
            )}
            
            <button
              onClick={() => onNavigate('explore')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                currentView === 'explore' 
                  ? 'bg-white/20 text-white' 
                  : 'text-gray-300 hover:text-white hover:bg-white/10'
              }`}
            >
              Explore Capsules
            </button>
          </nav>
          
          {/* Right Side Actions */}
          <div className="flex items-center space-x-4">
            {/* Mobile My Capsules Button */}
            {savedCapsulesCount > 0 && (
              <button 
                onClick={() => onNavigate('library')}
                className="md:hidden flex items-center gap-2 p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors duration-200"
              >
                <Archive className="w-5 h-5" />
                <span className="bg-yellow-400 text-purple-900 text-xs rounded-full w-5 h-5 flex items-center justify-center font-semibold">
                  {savedCapsulesCount}
                </span>
              </button>
            )}
            
            <button 
              onClick={() => onNavigate('profile')}
              className="flex items-center gap-2 p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors duration-200"
            >
              <Settings className="w-5 h-5" />
              <span className="hidden sm:inline">Profile</span>
            </button>
            
            {userProfile && (
              <div className="flex items-center gap-2 px-3 py-1 bg-white/10 rounded-full">
                <User className="w-4 h-4" />
                <span className="text-sm hidden sm:inline">{userProfile.name || 'User'}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default GlobalHeader;