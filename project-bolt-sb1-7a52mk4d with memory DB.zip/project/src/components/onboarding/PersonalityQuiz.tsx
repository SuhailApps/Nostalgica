import React, { useState } from 'react';
import { X, ArrowRight, ArrowLeft } from 'lucide-react';
import { PersonalityQuizResult } from '../../types';
import { personalityQuestions } from '../../data/onboarding';

interface PersonalityQuizProps {
  onComplete: (result: PersonalityQuizResult) => void;
  onClose: () => void;
}

const PersonalityQuiz: React.FC<PersonalityQuizProps> = ({ onComplete, onClose }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<string[]>([]);
  const [scores, setScores] = useState<Record<string, number>>({
    rebellious: 0,
    glam: 0,
    nerdy: 0,
    optimistic: 0,
    futuristic: 0,
    chill: 0,
    intense: 0,
  });

  const handleAnswer = (optionValue: string) => {
    const question = personalityQuestions[currentQuestion];
    const option = question.options.find(opt => opt.value === optionValue);
    
    if (option) {
      const newScores = { ...scores };
      Object.entries(option.points).forEach(([mood, points]) => {
        newScores[mood] += points;
      });
      setScores(newScores);
    }

    const newAnswers = [...answers];
    newAnswers[currentQuestion] = optionValue;
    setAnswers(newAnswers);

    if (currentQuestion < personalityQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      // Calculate result
      const topMood = Object.entries(newScores).reduce((a, b) => 
        newScores[a[0]] > newScores[b[0]] ? a : b
      )[0];

      const result: PersonalityQuizResult = {
        musicTaste: topMood,
        movieGenre: topMood,
        fashionStyle: topMood,
        lifestyle: topMood,
      };

      onComplete(result);
    }
  };

  const handleBack = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const question = personalityQuestions[currentQuestion];

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full">
        <div className="p-6 border-b border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-bold text-gray-800">Personality Quiz</h3>
              <p className="text-gray-600">Question {currentQuestion + 1} of {personalityQuestions.length}</p>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>
          
          <div className="mt-4 bg-gray-200 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${((currentQuestion + 1) / personalityQuestions.length) * 100}%` }}
            />
          </div>
        </div>

        <div className="p-6">
          <h4 className="text-lg font-semibold text-gray-800 mb-6">{question.question}</h4>
          
          <div className="space-y-3">
            {question.options.map((option) => (
              <button
                key={option.value}
                onClick={() => handleAnswer(option.value)}
                className="w-full p-4 text-left border-2 border-gray-200 rounded-xl hover:border-blue-300 hover:bg-blue-50 transition-all duration-200"
              >
                {option.label}
              </button>
            ))}
          </div>
        </div>

        <div className="p-6 border-t border-gray-100 flex justify-between">
          <button
            onClick={handleBack}
            disabled={currentQuestion === 0}
            className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:text-gray-800 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>
          
          <button
            onClick={onClose}
            className="px-4 py-2 text-gray-600 hover:text-gray-800"
          >
            Skip Quiz
          </button>
        </div>
      </div>
    </div>
  );
};

export default PersonalityQuiz;