import React, { useState } from 'react';
import { Calendar, MapPin, Heart, Sparkles, ArrowRight, ArrowLeft, X } from 'lucide-react';
import { OnboardingData } from '../../types';
import { decades, moods, lifeEventTemplates } from '../../data/onboarding';
import PersonalityQuiz from './PersonalityQuiz';
import SpotifyUpload from './SpotifyUpload';

interface OnboardingFlowProps {
  onComplete: (data: OnboardingData) => void;
  onCancel: () => void;
}

const OnboardingFlow: React.FC<OnboardingFlowProps> = ({ onComplete, onCancel }) => {
  const [step, setStep] = useState(1);
  const [data, setData] = useState<Partial<OnboardingData>>({});
  const [showQuiz, setShowQuiz] = useState(false);
  const [showSpotify, setShowSpotify] = useState(false);

  const totalSteps = 4;

  const handleNext = () => {
    if (step < totalSteps) {
      setStep(step + 1);
    } else {
      onComplete(data as OnboardingData);
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const handleQuickGenerate = () => {
    if (data.decade && data.year && data.mood) {
      onComplete({
        ...data,
        lifeEvent: data.lifeEvent || 'General nostalgia trip',
      } as OnboardingData);
    }
  };

  const isStepComplete = () => {
    switch (step) {
      case 1: return data.decade;
      case 2: return data.year;
      case 3: return data.mood;
      case 4: return data.lifeEvent;
      default: return false;
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-gray-800">Create Your Time Capsule</h2>
              <p className="text-gray-600 mt-1">Step {step} of {totalSteps}</p>
            </div>
            <button
              onClick={onCancel}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X className="w-6 h-6 text-gray-500" />
            </button>
          </div>
          
          {/* Progress Bar */}
          <div className="mt-4 bg-gray-200 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${(step / totalSteps) * 100}%` }}
            />
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {step === 1 && (
            <div className="space-y-6">
              <div className="text-center">
                <Calendar className="w-12 h-12 text-purple-500 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-800 mb-2">Choose Your Era</h3>
                <p className="text-gray-600">Which decade holds your most vivid memories?</p>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                {decades.map((decade) => (
                  <button
                    key={decade.value}
                    onClick={() => setData({ ...data, decade: decade.value })}
                    className={`p-6 rounded-2xl border-2 transition-all duration-200 ${
                      data.decade === decade.value
                        ? 'border-purple-500 bg-purple-50 shadow-lg transform scale-105'
                        : 'border-gray-200 hover:border-purple-300 hover:shadow-md'
                    }`}
                  >
                    <div className="text-3xl font-bold text-gray-800">{decade.label}</div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === 2 && data.decade && (
            <div className="space-y-6">
              <div className="text-center">
                <Calendar className="w-12 h-12 text-purple-500 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-800 mb-2">Pick the Exact Year</h3>
                <p className="text-gray-600">When did the magic happen?</p>
              </div>
              
              <div className="grid grid-cols-5 gap-3">
                {decades.find(d => d.value === data.decade)?.years.map((year) => (
                  <button
                    key={year}
                    onClick={() => setData({ ...data, year })}
                    className={`p-4 rounded-xl border-2 transition-all duration-200 ${
                      data.year === year
                        ? 'border-purple-500 bg-purple-50 shadow-lg transform scale-105'
                        : 'border-gray-200 hover:border-purple-300 hover:shadow-md'
                    }`}
                  >
                    <div className="font-semibold text-gray-800">{year}</div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <div className="text-center">
                <Heart className="w-12 h-12 text-purple-500 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-800 mb-2">Set Your Vibe</h3>
                <p className="text-gray-600">What mood defined that time for you?</p>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                {moods.map((mood) => (
                  <button
                    key={mood.value}
                    onClick={() => setData({ ...data, mood: mood.value })}
                    className={`p-6 rounded-2xl border-2 transition-all duration-200 ${
                      data.mood === mood.value
                        ? 'border-purple-500 bg-purple-50 shadow-lg transform scale-105'
                        : 'border-gray-200 hover:border-purple-300 hover:shadow-md'
                    }`}
                  >
                    <div className="text-3xl mb-2">{mood.emoji}</div>
                    <div className="font-semibold text-gray-800">{mood.label}</div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-6">
              <div className="text-center">
                <MapPin className="w-12 h-12 text-purple-500 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-800 mb-2">Add Context</h3>
                <p className="text-gray-600">Describe the moment or phase</p>
              </div>
              
              <div className="space-y-4">
                <input
                  type="text"
                  placeholder="e.g., My punk phase in California, 2002"
                  value={data.lifeEvent || ''}
                  onChange={(e) => setData({ ...data, lifeEvent: e.target.value })}
                  className="w-full p-4 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none text-lg"
                />
                
                <div className="text-sm text-gray-500 mb-4">Or choose from templates:</div>
                <div className="grid grid-cols-2 gap-2">
                  {lifeEventTemplates.map((template, index) => (
                    <button
                      key={index}
                      onClick={() => setData({ ...data, lifeEvent: template })}
                      className="p-3 text-left border border-gray-200 rounded-lg hover:border-purple-300 hover:bg-purple-50 transition-colors text-sm"
                    >
                      {template}
                    </button>
                  ))}
                </div>

              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-gray-100 flex items-center justify-between">
          <button
            onClick={handleBack}
            disabled={step === 1}
            className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:text-gray-800 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>

          <div className="flex gap-3">
            {step >= 3 && (
              <button
                onClick={handleQuickGenerate}
                className="px-6 py-3 bg-gray-500 text-white rounded-xl hover:bg-gray-600 transition-colors"
              >
                Quick Generate
              </button>
            )}
            
            <button
              onClick={handleNext}
              disabled={!isStepComplete()}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {step === totalSteps ? 'Create Capsule' : 'Next'}
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Modals */}
      {showQuiz && (
        <PersonalityQuiz
          onComplete={(result) => {
            setData({ ...data, personalityQuiz: result });
            setShowQuiz(false);
          }}
          onClose={() => setShowQuiz(false)}
        />
      )}

      {showSpotify && (
        <SpotifyUpload
          onComplete={(spotifyData) => {
            setData({ ...data, spotifyData });
            setShowSpotify(false);
          }}
          onClose={() => setShowSpotify(false)}
        />
      )}
    </div>
  );
};

export default OnboardingFlow;