import React, { useState } from 'react';
import { X, Upload, Music, ExternalLink } from 'lucide-react';

interface SpotifyUploadProps {
  onComplete: (data: any) => void;
  onClose: () => void;
}

const SpotifyUpload: React.FC<SpotifyUploadProps> = ({ onComplete, onClose }) => {
  const [uploadMethod, setUploadMethod] = useState<'connect' | 'manual' | null>(null);
  const [manualData, setManualData] = useState('');

  const handleSpotifyConnect = () => {
    // In a real app, this would initiate Spotify OAuth
    alert('Spotify connection would be implemented here');
    onComplete({ method: 'spotify', connected: true });
  };

  const handleManualSubmit = () => {
    if (manualData.trim()) {
      onComplete({ method: 'manual', data: manualData });
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full">
        <div className="p-6 border-b border-gray-100">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold text-gray-800">Music Preferences</h3>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>
        </div>

        <div className="p-6">
          {!uploadMethod ? (
            <div className="space-y-4">
              <p className="text-gray-600 mb-6">Help us understand your music taste better</p>
              
              <button
                onClick={() => setUploadMethod('connect')}
                className="w-full p-4 bg-green-500 text-white rounded-xl hover:bg-green-600 transition-colors flex items-center justify-center gap-3"
              >
                <Music className="w-5 h-5" />
                Connect Spotify Account
                <ExternalLink className="w-4 h-4" />
              </button>
              
              <div className="text-center text-gray-500">or</div>
              
              <button
                onClick={() => setUploadMethod('manual')}
                className="w-full p-4 border-2 border-gray-200 rounded-xl hover:border-gray-300 transition-colors flex items-center justify-center gap-3"
              >
                <Upload className="w-5 h-5" />
                Describe Your Music Taste
              </button>
            </div>
          ) : uploadMethod === 'connect' ? (
            <div className="text-center space-y-4">
              <Music className="w-16 h-16 text-green-500 mx-auto" />
              <h4 className="text-lg font-semibold">Connect to Spotify</h4>
              <p className="text-gray-600">We'll analyze your listening history to create better recommendations</p>
              <button
                onClick={handleSpotifyConnect}
                className="w-full p-4 bg-green-500 text-white rounded-xl hover:bg-green-600 transition-colors"
              >
                Authorize Spotify Access
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              <h4 className="text-lg font-semibold">Describe Your Music Taste</h4>
              <textarea
                value={manualData}
                onChange={(e) => setManualData(e.target.value)}
                placeholder="e.g., I love indie rock, especially bands like Arctic Monkeys and The Strokes. I also enjoy some electronic music and 90s hip-hop..."
                className="w-full h-32 p-4 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none resize-none"
              />
              <button
                onClick={handleManualSubmit}
                disabled={!manualData.trim()}
                className="w-full p-4 bg-purple-500 text-white rounded-xl hover:bg-purple-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Save Preferences
              </button>
            </div>
          )}
        </div>

        {uploadMethod && (
          <div className="p-6 border-t border-gray-100">
            <button
              onClick={() => setUploadMethod(null)}
              className="text-gray-600 hover:text-gray-800"
            >
              ← Back to options
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default SpotifyUpload;