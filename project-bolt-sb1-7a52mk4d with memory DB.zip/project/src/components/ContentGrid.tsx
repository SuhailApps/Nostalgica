import React from 'react';
import { Search } from 'lucide-react';
import { CulturalContent } from '../types';
import ContentCard from './ContentCard';

interface ContentGridProps {
  content: CulturalContent[];
  bookmarkedIds: string[];
  onBookmark: (id: string) => void;
  searchTerm: string;
  onSearchChange: (term: string) => void;
}

const ContentGrid: React.FC<ContentGridProps> = ({
  content,
  bookmarkedIds,
  onBookmark,
  searchTerm,
  onSearchChange,
}) => {
  return (
    <div className="space-y-6">
      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
        <input
          type="text"
          placeholder="Search cultural memories..."
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
          className="w-full pl-12 pr-4 py-4 bg-white/80 backdrop-blur-sm rounded-2xl border-0 shadow-xl focus:shadow-2xl transition-shadow duration-300 text-gray-800 placeholder-gray-500 text-lg"
        />
      </div>

      {/* Results Count */}
      <div className="text-gray-600 text-lg">
        {content.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">🕰️</div>
            <p className="text-xl">No memories found for your time travel criteria</p>
            <p className="text-gray-500 mt-2">Try adjusting your filters or search term</p>
          </div>
        ) : (
          <p>
            Discovered <span className="font-bold text-purple-600">{content.length}</span> cultural memories
          </p>
        )}
      </div>

      {/* Content Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {content.map((item) => (
          <ContentCard
            key={item.id}
            content={item}
            onBookmark={onBookmark}
            isBookmarked={bookmarkedIds.includes(item.id)}
          />
        ))}
      </div>
    </div>
  );
};

export default ContentGrid;