import React, { useState } from 'react';
import { Share2, Download, Heart, Music, Package, BookOpen, TrendingUp, Instagram, Video, Camera } from 'lucide-react';
import { TimeCapsule } from '../types';

interface TimeCapsuleDashboardProps {
  capsule: TimeCapsule;
  onShare: (format: string) => void;
  onSave: () => void;
  onExploreMore: () => void;
}

const TimeCapsuleDashboard: React.FC<TimeCapsuleDashboardProps> = ({
  capsule,
  onShare,
  onSave,
  onExploreMore
}) => {
  const [activeTab, setActiveTab] = useState<'playlist' | 'starter' | 'memoir' | 'comparison'>('playlist');

  const tabs = [
    { id: 'playlist', label: 'Playlist', icon: Music },
    { id: 'starter', label: 'Starter Pack', icon: Package },
    { id: 'memoir', label: 'Memoir', icon: BookOpen },
    { id: 'comparison', label: 'Then vs. Now', icon: TrendingUp },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-red-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-2xl p-8 mb-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-4xl font-bold text-gray-800 mb-2">
                YOUR TIME CAPSULE
              </h1>
              <div className="flex items-center gap-4 text-2xl font-bold text-gray-600">
                <span>{capsule.year}</span>
                <span className="text-orange-500">•</span>
                <span className="uppercase">{capsule.location}</span>
              </div>
            </div>
            <div className="text-right">
              <div className="text-6xl font-bold text-orange-500">{capsule.year}</div>
              <div className="text-sm text-gray-600 uppercase tracking-wider">{capsule.location}</div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <button
              onClick={onSave}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl hover:shadow-lg transition-all"
            >
              <Heart className="w-5 h-5" />
              Save Capsule
            </button>
            <button
              onClick={() => onShare('instagram')}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-pink-500 to-red-500 text-white rounded-xl hover:shadow-lg transition-all"
            >
              <Instagram className="w-5 h-5" />
              Share Story
            </button>
            <button
              onClick={() => onShare('tiktok')}
              className="flex items-center gap-2 px-6 py-3 bg-black text-white rounded-xl hover:shadow-lg transition-all"
            >
              <Video className="w-5 h-5" />
              TikTok
            </button>
            <button
              onClick={() => onShare('reels')}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-xl hover:shadow-lg transition-all"
            >
              <Camera className="w-5 h-5" />
              Reels
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-2xl overflow-hidden">
          <div className="flex border-b border-gray-200">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex-1 flex items-center justify-center gap-2 py-4 px-6 font-semibold transition-all ${
                    activeTab === tab.id
                      ? 'bg-orange-500 text-white'
                      : 'text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  {tab.label}
                </button>
              );
            })}
          </div>

          <div className="p-8">
            {activeTab === 'playlist' && (
              <div>
                <h3 className="text-2xl font-bold text-gray-800 mb-6">Playlist</h3>
                <div className="grid gap-4">
                  {capsule.playlist.map((song) => (
                    <div key={song.id} className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors">
                      <img
                        src={song.imageUrl}
                        alt={song.title}
                        className="w-16 h-16 rounded-lg object-cover"
                      />
                      <div className="flex-1">
                        <h4 className="font-semibold text-gray-800">{song.title}</h4>
                        <p className="text-gray-600">{song.artist}</p>
                        {song.album && <p className="text-sm text-gray-500">{song.album}</p>}
                      </div>
                      <Music className="w-5 h-5 text-gray-400" />
                    </div>
                  ))}
                </div>
                <div className="mt-6 p-4 bg-green-500 text-white rounded-xl flex items-center gap-3">
                  <Music className="w-6 h-6" />
                  <span className="font-semibold">Open in Spotify</span>
                </div>
              </div>
            )}

            {activeTab === 'starter' && (
              <div>
                <h3 className="text-2xl font-bold text-gray-800 mb-6">Starter Pack</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  {capsule.starterPack.map((item) => (
                    <div key={item.id} className="text-center p-6 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors">
                      <div className="text-4xl mb-3">{item.icon}</div>
                      <h4 className="font-semibold text-gray-800 mb-2">{item.name}</h4>
                      <p className="text-sm text-gray-600">{item.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'memoir' && (
              <div>
                <h3 className="text-2xl font-bold text-gray-800 mb-6">Memoir Snippet</h3>
                <div className="bg-amber-50 border-l-4 border-amber-400 p-6 rounded-r-xl">
                  <p className="text-lg leading-relaxed text-gray-700 italic">
                    "{capsule.memoirSnippet}"
                  </p>
                </div>
              </div>
            )}

            {activeTab === 'comparison' && (
              <div>
                <h3 className="text-2xl font-bold text-gray-800 mb-6">Then vs. Now</h3>
                <div className="grid md:grid-cols-2 gap-8">
                  <div>
                    <h4 className="text-xl font-semibold text-orange-600 mb-4">THEN</h4>
                    {Object.entries(capsule.thenVsNow.then).map(([category, items]) => (
                      <div key={category} className="mb-4">
                        <h5 className="font-semibold text-gray-700 capitalize mb-2">{category}</h5>
                        <div className="flex flex-wrap gap-2">
                          {Array.isArray(items) ? items.map((item, index) => (
                            <span key={index} className="px-3 py-1 bg-orange-100 text-orange-800 rounded-full text-sm">
                              {item}
                            </span>
                          )) : null}
                        </div>
                      </div>
                    ))}
                  </div>
                  <div>
                    <h4 className="text-xl font-semibold text-blue-600 mb-4">NOW</h4>
                    {Object.entries(capsule.thenVsNow.now).map(([category, items]) => (
                      <div key={category} className="mb-4">
                        <h5 className="font-semibold text-gray-700 capitalize mb-2">{category}</h5>
                        <div className="flex flex-wrap gap-2">
                          {Array.isArray(items) ? items.map((item, index) => (
                            <span key={index} className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                              {item}
                            </span>
                          )) : null}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="mt-8 text-center">
          <button
            onClick={onExploreMore}
            className="px-8 py-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl hover:shadow-lg transition-all text-lg font-semibold"
          >
            Create Another Time Capsule
          </button>
        </div>
      </div>
    </div>
  );
};

export default TimeCapsuleDashboard;