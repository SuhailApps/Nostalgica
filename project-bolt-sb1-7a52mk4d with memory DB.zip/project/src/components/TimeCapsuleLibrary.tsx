import React, { useState, useMemo } from 'react';
import { Search, Filter, Calendar, Heart, MapPin, Clock, Music, Package, BookOpen, TrendingUp, Grid, List, SortAsc, SortDesc } from 'lucide-react';
import { TimeCapsule } from '../types';

interface TimeCapsuleLibraryProps {
  capsules: TimeCapsule[];
  isLoading?: boolean;
  onViewCapsule: (capsule: TimeCapsule) => void;
  onBack?: () => void;
  onDeleteCapsule?: (capsuleId: string) => void;
}

const TimeCapsuleLibrary: React.FC<TimeCapsuleLibraryProps> = ({
  capsules,
  isLoading = false,
  onViewCapsule,
  onBack,
  onDeleteCapsule
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDecade, setSelectedDecade] = useState<string>('');
  const [selectedYear, setSelectedYear] = useState<string>('');
  const [selectedMood, setSelectedMood] = useState<string>('');
  const [selectedContext, setSelectedContext] = useState<string>('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState<'date' | 'year' | 'mood' | 'context'>('date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [showFilters, setShowFilters] = useState(false);

  // Extract unique values for filters
  const decades = useMemo(() => {
    const decadeSet = new Set(capsules.map(c => `${Math.floor(c.year / 10) * 10}s`));
    return Array.from(decadeSet).sort();
  }, [capsules]);

  const years = useMemo(() => {
    const yearSet = new Set(capsules.map(c => c.year.toString()));
    return Array.from(yearSet).sort((a, b) => parseInt(b) - parseInt(a));
  }, [capsules]);

  const moods = useMemo(() => {
    const moodSet = new Set(capsules.map(c => c.mood));
    return Array.from(moodSet).sort();
  }, [capsules]);

  const contexts = useMemo(() => {
    const contextSet = new Set(capsules.map(c => c.lifeEvent));
    return Array.from(contextSet).sort();
  }, [capsules]);

  // Filter and sort capsules
  const filteredAndSortedCapsules = useMemo(() => {
    let filtered = capsules.filter(capsule => {
      const matchesSearch = searchTerm === '' || 
        capsule.lifeEvent.toLowerCase().includes(searchTerm.toLowerCase()) ||
        capsule.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
        capsule.mood.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesDecade = selectedDecade === '' || 
        `${Math.floor(capsule.year / 10) * 10}s` === selectedDecade;

      const matchesYear = selectedYear === '' || 
        capsule.year.toString() === selectedYear;

      const matchesMood = selectedMood === '' || 
        capsule.mood === selectedMood;

      const matchesContext = selectedContext === '' || 
        capsule.lifeEvent === selectedContext;

      return matchesSearch && matchesDecade && matchesYear && matchesMood && matchesContext;
    });

    // Sort capsules
    filtered.sort((a, b) => {
      let comparison = 0;
      
      switch (sortBy) {
        case 'date':
          comparison = a.createdAt.getTime() - b.createdAt.getTime();
          break;
        case 'year':
          comparison = a.year - b.year;
          break;
        case 'mood':
          comparison = a.mood.localeCompare(b.mood);
          break;
        case 'context':
          comparison = a.lifeEvent.localeCompare(b.lifeEvent);
          break;
      }

      return sortOrder === 'asc' ? comparison : -comparison;
    });

    return filtered;
  }, [capsules, searchTerm, selectedDecade, selectedYear, selectedMood, selectedContext, sortBy, sortOrder]);

  const clearFilters = () => {
    setSearchTerm('');
    setSelectedDecade('');
    setSelectedYear('');
    setSelectedMood('');
    setSelectedContext('');
  };

  const activeFiltersCount = [selectedDecade, selectedYear, selectedMood, selectedContext].filter(Boolean).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-pink-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-2xl p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-800">My Capsules</h1>
              <p className="text-gray-600">Browse and explore your time capsule collection</p>
            </div>
            
            <div className="flex items-center gap-3">
              {/* View Mode Toggle */}
              <div className="flex bg-gray-100 rounded-lg p-1">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 rounded-md transition-colors ${
                    viewMode === 'grid' ? 'bg-white shadow-sm' : 'hover:bg-gray-200'
                  }`}
                >
                  <Grid className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2 rounded-md transition-colors ${
                    viewMode === 'list' ? 'bg-white shadow-sm' : 'hover:bg-gray-200'
                  }`}
                >
                  <List className="w-4 h-4" />
                </button>
              </div>

              {/* Sort Controls */}
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="px-3 py-2 border border-gray-200 rounded-lg focus:border-purple-500 focus:outline-none"
              >
                <option value="date">Sort by Date</option>
                <option value="year">Sort by Year</option>
                <option value="mood">Sort by Mood</option>
                <option value="context">Sort by Context</option>
              </select>

              <button
                onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
                className="p-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
              >
                {sortOrder === 'asc' ? <SortAsc className="w-4 h-4" /> : <SortDesc className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Search and Filter Bar */}
          <div className="flex gap-4 items-center">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search by context, location, or mood..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none"
              />
            </div>
            
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`flex items-center gap-2 px-4 py-3 rounded-xl border transition-colors ${
                showFilters || activeFiltersCount > 0
                  ? 'bg-purple-500 text-white border-purple-500'
                  : 'border-gray-200 hover:bg-gray-50'
              }`}
            >
              <Filter className="w-5 h-5" />
              Filters
              {activeFiltersCount > 0 && (
                <span className="bg-white text-purple-500 text-xs rounded-full w-5 h-5 flex items-center justify-center font-semibold">
                  {activeFiltersCount}
                </span>
              )}
            </button>
          </div>

          {/* Filter Panel */}
          {showFilters && (
            <div className="mt-6 p-6 bg-gray-50 rounded-2xl">
              <div className="grid md:grid-cols-4 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Decade</label>
                  <select
                    value={selectedDecade}
                    onChange={(e) => setSelectedDecade(e.target.value)}
                    className="w-full p-2 border border-gray-200 rounded-lg focus:border-purple-500 focus:outline-none"
                  >
                    <option value="">All Decades</option>
                    {decades.map(decade => (
                      <option key={decade} value={decade}>{decade}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Year</label>
                  <select
                    value={selectedYear}
                    onChange={(e) => setSelectedYear(e.target.value)}
                    className="w-full p-2 border border-gray-200 rounded-lg focus:border-purple-500 focus:outline-none"
                  >
                    <option value="">All Years</option>
                    {years.map(year => (
                      <option key={year} value={year}>{year}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Mood</label>
                  <select
                    value={selectedMood}
                    onChange={(e) => setSelectedMood(e.target.value)}
                    className="w-full p-2 border border-gray-200 rounded-lg focus:border-purple-500 focus:outline-none"
                  >
                    <option value="">All Moods</option>
                    {moods.map(mood => (
                      <option key={mood} value={mood}>{mood}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Context</label>
                  <select
                    value={selectedContext}
                    onChange={(e) => setSelectedContext(e.target.value)}
                    className="w-full p-2 border border-gray-200 rounded-lg focus:border-purple-500 focus:outline-none"
                  >
                    <option value="">All Contexts</option>
                    {contexts.map(context => (
                      <option key={context} value={context}>{context}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">
                  {filteredAndSortedCapsules.length} of {capsules.length} capsules
                </span>
                <button
                  onClick={clearFilters}
                  className="text-sm text-purple-600 hover:text-purple-800 font-medium"
                >
                  Clear All Filters
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Results */}
        {isLoading ? (
          <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl p-12 text-center">
            <Clock className="w-16 h-16 text-purple-600 mx-auto mb-4 animate-spin" />
            <h3 className="text-2xl font-semibold text-gray-800 mb-2">Loading Your Time Capsules</h3>
            <p className="text-gray-600">Please wait while we fetch your memories...</p>
          </div>
        ) : filteredAndSortedCapsules.length === 0 ? (
          <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl p-12 text-center">
            <Clock className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-2xl font-semibold text-gray-800 mb-2">No Time Capsules Found</h3>
            <p className="text-gray-600 mb-6">
              {capsules.length === 0 
                ? "You haven't created any time capsules yet."
                : "No capsules match your current filters."
              }
            </p>
            {activeFiltersCount > 0 && (
              <button
                onClick={clearFilters}
                className="px-6 py-3 bg-purple-500 text-white rounded-xl hover:bg-purple-600 transition-colors"
              >
                Clear Filters
              </button>
            )}
          </div>
        ) : (
          <div className={viewMode === 'grid' 
            ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            : "space-y-4"
          }>
            {filteredAndSortedCapsules.map((capsule) => (
              <CapsuleCard
                key={capsule.id}
                capsule={capsule}
                viewMode={viewMode}
                onView={() => onViewCapsule(capsule)}
                onDelete={onDeleteCapsule ? () => onDeleteCapsule(capsule.id) : undefined}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

interface CapsuleCardProps {
  capsule: TimeCapsule;
  viewMode: 'grid' | 'list';
  onView: () => void;
  onDelete?: () => void;
}

const CapsuleCard: React.FC<CapsuleCardProps> = ({ capsule, viewMode, onView, onDelete }) => {
  if (viewMode === 'list') {
    return (
      <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl p-6 hover:shadow-2xl transition-all cursor-pointer"
           onClick={onView}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-500">{capsule.year}</div>
              <div className="text-sm text-gray-600 uppercase tracking-wider">{capsule.location}</div>
            </div>
            
            <div className="flex-1">
              <h3 className="text-xl font-semibold text-gray-800 mb-2">{capsule.lifeEvent}</h3>
              <div className="flex items-center gap-4 text-sm text-gray-600">
                <div className="flex items-center gap-1">
                  <Heart className="w-4 h-4" />
                  <span className="capitalize">{capsule.mood}</span>
                </div>
                <div className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  <span>{capsule.location}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  <span>{capsule.createdAt.toLocaleDateString()}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 text-sm text-gray-600">
              <Music className="w-4 h-4" />
              <span>{capsule.playlist.length}</span>
            </div>
            <div className="flex items-center gap-1 text-sm text-gray-600">
              <Package className="w-4 h-4" />
              <span>{capsule.starterPack.length}</span>
            </div>
            {onDelete && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  if (confirm('Are you sure you want to delete this time capsule?')) {
                    onDelete();
                  }
                }}
                className="text-red-500 hover:text-red-700 text-sm"
              >
                Delete
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl overflow-hidden hover:shadow-2xl transition-all cursor-pointer group"
         onClick={onView}>
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="text-center">
            <div className="text-4xl font-bold text-orange-500">{capsule.year}</div>
            <div className="text-sm text-gray-600 uppercase tracking-wider">{capsule.location}</div>
          </div>
          <div className="text-right">
            <div className="text-sm text-gray-500">
              {capsule.createdAt.toLocaleDateString()}
            </div>
          </div>
        </div>

        <h3 className="text-xl font-semibold text-gray-800 mb-3 group-hover:text-purple-600 transition-colors">
          {capsule.lifeEvent}
        </h3>

        <div className="flex items-center gap-2 mb-4">
          <Heart className="w-4 h-4 text-pink-500" />
          <span className="text-sm text-gray-600 capitalize">{capsule.mood}</span>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Music className="w-4 h-4 text-purple-500" />
            <span>{capsule.playlist.length} songs</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Package className="w-4 h-4 text-blue-500" />
            <span>{capsule.starterPack.length} items</span>
          </div>
        </div>

        <div className="text-sm text-gray-600 line-clamp-2 mb-4">
          {capsule.memoirSnippet}
        </div>

        <div className="flex justify-between items-center">
          <div className="flex gap-2">
            <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
              <Music className="w-4 h-4 text-purple-600" />
            </div>
            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
              <Package className="w-4 h-4 text-blue-600" />
            </div>
            <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
              <BookOpen className="w-4 h-4 text-green-600" />
            </div>
            <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center">
              <TrendingUp className="w-4 h-4 text-orange-600" />
            </div>
          </div>
          
          <button className="text-purple-600 hover:text-purple-800 font-medium text-sm group-hover:underline">
            View Capsule →
          </button>
          
          {onDelete && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                if (confirm('Are you sure you want to delete this time capsule?')) {
                  onDelete();
                }
              }}
              className="text-red-500 hover:text-red-700 text-sm"
            >
              Delete
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default TimeCapsuleLibrary;