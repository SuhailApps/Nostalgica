import { OnboardingData, LLMResponse, UserProfile } from '../types';

export class LLMService {
  private profile: UserProfile;

  constructor(profile: UserProfile) {
    this.profile = profile;
  }

  async generateCulturalSeeds(onboardingData: OnboardingData): Promise<LLMResponse> {
    const prompt = this.buildPrompt(onboardingData);
    
    try {
      const response = await this.callLLM(prompt);
      return this.parseLLMResponse(response);
    } catch (error) {
      console.error('LLM API Error:', error);
      throw new Error('Failed to generate cultural seeds');
    }
  }

  private buildPrompt(data: OnboardingData): string {
    return `You are a cultural historian and nostalgia expert. Based on the following user input, generate cultural touchpoints and insights for their time capsule.

User Input:
- Year: ${data.year}
- Decade: ${data.decade}
- Life Event: ${data.lifeEvent}
- Mood: ${data.mood}
- Location: ${data.location || 'Unknown'}
${data.personalityQuiz ? `- Personality: ${JSON.stringify(data.personalityQuiz)}` : ''}
${data.spotifyData ? `- Music Preferences: ${JSON.stringify(data.spotifyData)}` : ''}

Please respond with a JSON object containing:

1. culturalSeeds: Object with arrays for music, movies, fashion, food, travel (5-10 items each)
2. memoirSnippet: A nostalgic 2-3 sentence memoir snippet in second person ("You could be found...")
3. thenVsNow: Comparison object with "then" and "now" arrays for music, movies, fashion, travel, food (3-5 items each)

Focus on authentic cultural touchpoints from ${data.year} that match the "${data.mood}" mood and "${data.lifeEvent}" context. Be specific and evocative. Only include music, movies, food, fashion, and travel - no technology products or gadgets.

Respond only with valid JSON, no additional text.`;
  }

  private async callLLM(prompt: string): Promise<string> {
    const provider = this.profile.llmProvider;
    
    if (provider === 'openai') {
      return this.callOpenAI(prompt);
    } else if (provider === 'anthropic') {
      return this.callAnthropic(prompt);
    } else if (provider === 'deepseek') {
      return this.callDeepSeek(prompt);
    }
    
    throw new Error(`Unsupported LLM provider: ${provider}`);
  }

  private async callOpenAI(prompt: string): Promise<string> {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.profile.llmApiKey}`,
      },
      body: JSON.stringify({
        model: this.profile.llmModel,
        messages: [
          {
            role: 'system',
            content: 'You are a cultural historian and nostalgia expert. Always respond with valid JSON only.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.7,
        max_tokens: 2000,
      }),
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;
  }

  private async callAnthropic(prompt: string): Promise<string> {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': this.profile.llmApiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: this.profile.llmModel,
        max_tokens: 2000,
        messages: [
          {
            role: 'user',
            content: prompt
          }
        ],
      }),
    });

    if (!response.ok) {
      throw new Error(`Anthropic API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.content[0].text;
  }

  private async callDeepSeek(prompt: string): Promise<string> {
    const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.profile.llmApiKey}`,
      },
      body: JSON.stringify({
        model: this.profile.llmModel,
        messages: [
          {
            role: 'system',
            content: 'You are a cultural historian and nostalgia expert. Always respond with valid JSON only.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.7,
        max_tokens: 2000,
      }),
    });

    if (!response.ok) {
      throw new Error(`DeepSeek API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;
  }

  private parseLLMResponse(response: string): LLMResponse {
    try {
      // Clean the response to extract JSON
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        alert(`LLM Response Parse Error: No JSON found in response: ${response}`);
        throw new Error('No JSON found in LLM response');
      }
      
      const parsed = JSON.parse(jsonMatch[0]);
      
      // Validate the structure
      if (!parsed.culturalSeeds || !parsed.memoirSnippet || !parsed.thenVsNow) {
        alert(`LLM Response Structure Error: Missing required fields. Response: ${JSON.stringify(parsed, null, 2)}`);
        throw new Error('Invalid LLM response structure');
      }
      
      // Ensure thenVsNow structure is properly initialized
      const defaultCategories = {
        music: [],
        movies: [],
        fashion: [],
        travel: [],
        food: []
      };
      
      // Initialize thenVsNow with proper structure
      parsed.thenVsNow = {
        then: {
          ...defaultCategories,
          ...(parsed.thenVsNow?.then || {})
        },
        now: {
          ...defaultCategories,
          ...(parsed.thenVsNow?.now || {})
        }
      };
      
      return parsed as LLMResponse;
    } catch (error) {
      console.error('Failed to parse LLM response:', error);
      throw new Error('Invalid response format from LLM');
    }
  }

  async callLLMDirect(prompt: string): Promise<string> {
    return this.callLLM(prompt);
  }
}