import { UserProfile, TimeCapsule } from '../types';

// In-memory storage
let users: Map<string, UserProfile> = new Map();
let timeCapsules: Map<string, TimeCapsule[]> = new Map();
let currentUser: any = null;

export class MemoryDatabaseService {
  // Authentication Methods
  async signUp(email: string, password: string): Promise<{ user: any; error: any }> {
    // Check if user already exists
    const existingUser = Array.from(users.values()).find(u => u.email === email);
    if (existingUser) {
      return { user: null, error: { message: 'User already exists' } };
    }

    // Create new user
    const user = {
      id: Date.now().toString(),
      email,
      created_at: new Date().toISOString()
    };

    currentUser = user;
    return { user, error: null };
  }

  async signIn(email: string, password: string): Promise<{ user: any; error: any }> {
    // Find user by email
    const userProfile = Array.from(users.values()).find(u => u.email === email);
    if (!userProfile) {
      return { user: null, error: { message: 'Invalid email or password' } };
    }

    const user = {
      id: userProfile.id,
      email: userProfile.email,
      created_at: new Date().toISOString()
    };

    currentUser = user;
    return { user, error: null };
  }

  async signOut(): Promise<{ error: any }> {
    currentUser = null;
    return { error: null };
  }

  async getCurrentUser() {
    return currentUser;
  }

  // User Profile Methods
  async saveUserProfile(profile: UserProfile): Promise<UserProfile> {
    const updatedProfile = {
      ...profile,
      updatedAt: new Date()
    };
    
    users.set(profile.id, updatedProfile);
    return updatedProfile;
  }

  async getUserProfile(userId: string): Promise<UserProfile | null> {
    return users.get(userId) || null;
  }

  // Time Capsule Methods
  async saveTimeCapsule(capsule: TimeCapsule, userId: string): Promise<TimeCapsule> {
    const userCapsules = timeCapsules.get(userId) || [];
    const updatedCapsule = {
      ...capsule,
      createdAt: new Date()
    };
    
    userCapsules.push(updatedCapsule);
    timeCapsules.set(userId, userCapsules);
    
    return updatedCapsule;
  }

  async getUserTimeCapsules(userId: string): Promise<TimeCapsule[]> {
    const userCapsules = timeCapsules.get(userId) || [];
    return userCapsules.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async deleteTimeCapsule(capsuleId: string, userId: string): Promise<void> {
    const userCapsules = timeCapsules.get(userId) || [];
    const filteredCapsules = userCapsules.filter(c => c.id !== capsuleId);
    timeCapsules.set(userId, filteredCapsules);
  }

  async updateTimeCapsule(capsule: TimeCapsule, userId: string): Promise<TimeCapsule> {
    const userCapsules = timeCapsules.get(userId) || [];
    const index = userCapsules.findIndex(c => c.id === capsule.id);
    
    if (index === -1) {
      throw new Error('Time capsule not found');
    }

    const updatedCapsule = {
      ...capsule,
      createdAt: userCapsules[index].createdAt // Keep original creation date
    };
    
    userCapsules[index] = updatedCapsule;
    timeCapsules.set(userId, userCapsules);
    
    return updatedCapsule;
  }

  // Auth state change simulation
  onAuthStateChange(callback: (event: string, session: any) => void) {
    // Return a mock subscription object
    return {
      data: {
        subscription: {
          unsubscribe: () => {}
        }
      }
    };
  }
}

export const memoryDatabase = new MemoryDatabaseService();