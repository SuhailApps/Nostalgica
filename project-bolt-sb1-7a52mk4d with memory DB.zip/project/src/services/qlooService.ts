import { QlooRecommendation } from '../types';

export class QlooService {
  private baseUrl = 'https://hackathon.api.qloo.com';
  private apiKey: string;

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  async getRecommendations(seeds: string[], domain: string): Promise<QlooRecommendation[]> {
    try {
      const response = await fetch(`${this.baseUrl}/v2/insights`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`,
        },
        body: JSON.stringify({
          seeds: seeds,
          domain: domain,
          limit: 10,
        }),
      });

      if (!response.ok) {
        return this.getFallbackRecommendations(domain);
      }

      const data = await response.json();
      
      return this.parseQlooResponse(data, domain);
    } catch (error) {
      return this.getFallbackRecommendations(domain);
    }
  }

  async getCrossDomainRecommendations(culturalSeeds: {
    music: string[];
    movies: string[];
    fashion: string[];
    food: string[];
    travel: string[];
  }) {
    const recommendations = await Promise.all([
      this.getRecommendations(culturalSeeds.music, 'music'),
      this.getRecommendations(culturalSeeds.movies, 'movies'),
      this.getRecommendations(culturalSeeds.fashion, 'fashion'),
      this.getRecommendations(culturalSeeds.food, 'food'),
      this.getRecommendations(culturalSeeds.travel, 'travel'),
    ]);

    return {
      music: recommendations[0],
      movies: recommendations[1],
      fashion: recommendations[2],
      food: recommendations[3],
      travel: recommendations[4],
    };
  }

  private parseQlooResponse(data: any, domain: string): QlooRecommendation[] {
    if (!data.results || !Array.isArray(data.results)) {
      return [];
    }

    return data.results.map((item: any, index: number) => ({
      id: item.id || `${domain}-${index}`,
      name: item.name || item.title || 'Unknown',
      type: domain,
      score: item.score || Math.random() * 100,
      metadata: {
        artist: item.artist,
        album: item.album,
        year: item.year,
        genre: item.genre,
        director: item.director,
        brand: item.brand,
        category: item.category,
        imageUrl: item.image_url || this.getDefaultImage(domain),
      },
    }));
  }

  private getFallbackRecommendations(domain: string): QlooRecommendation[] {
    const fallbacks: Record<string, QlooRecommendation[]> = {
      music: [
        {
          id: 'music-1',
          name: 'Smells Like Teen Spirit',
          type: 'music',
          score: 95,
          metadata: {
            artist: 'Nirvana',
            album: 'Nevermind',
            year: 1991,
            genre: 'Grunge',
            imageUrl: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=400',
          },
        },
        {
          id: 'music-2',
          name: 'Creep',
          type: 'music',
          score: 88,
          metadata: {
            artist: 'Radiohead',
            album: 'Pablo Honey',
            year: 1992,
            genre: 'Alternative Rock',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
          },
        },
        {
          id: 'music-3',
          name: 'Wonderwall',
          type: 'music',
          score: 92,
          metadata: {
            artist: 'Oasis',
            album: '(What\'s the Story) Morning Glory?',
            year: 1995,
            genre: 'Britpop',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
          },
        },
        {
          id: 'music-4',
          name: 'Black',
          type: 'music',
          score: 89,
          metadata: {
            artist: 'Pearl Jam',
            album: 'Ten',
            year: 1991,
            genre: 'Grunge',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
          },
        },
        {
          id: 'music-5',
          name: 'Losing My Religion',
          type: 'music',
          score: 87,
          metadata: {
            artist: 'R.E.M.',
            album: 'Out of Time',
            year: 1991,
            genre: 'Alternative Rock',
            imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
          },
        },
      ],
      movies: [
        {
          id: 'movie-1',
          name: 'Reality Bites',
          type: 'movies',
          score: 92,
          metadata: {
            director: 'Ben Stiller',
            year: 1994,
            genre: 'Comedy-Drama',
            imageUrl: 'https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=400',
          },
        },
      ],
      fashion: [
        {
          id: 'fashion-1',
          name: 'Flannel Shirt',
          type: 'fashion',
          score: 90,
          metadata: {
            brand: 'Generic',
            category: 'Clothing',
            imageUrl: 'https://images.pexels.com/photos/9506/pexels-photo-9506.jpeg?auto=compress&cs=tinysrgb&w=400',
          },
        },
      ],
      food: [
        {
          id: 'food-1',
          name: 'Coffee Culture',
          type: 'food',
          score: 85,
          metadata: {
            category: 'Beverage',
            imageUrl: 'https://images.pexels.com/photos/4009402/pexels-photo-4009402.jpeg?auto=compress&cs=tinysrgb&w=400',
          },
        },
      ],
      technology: [
        {
          id: 'tech-1',
          name: 'Sony Walkman',
          type: 'technology',
          score: 88,
          metadata: {
            brand: 'Sony',
            category: 'Audio',
            year: 1990,
            imageUrl: 'https://images.pexels.com/photos/1649771/pexels-photo-1649771.jpeg?auto=compress&cs=tinysrgb&w=400',
          },
        },
      ],
    };

    return fallbacks[domain] || [];
  }

  private getDefaultImage(domain: string): string {
    const defaultImages: Record<string, string> = {
      music: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
      movies: 'https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=400',
      fashion: 'https://images.pexels.com/photos/9506/pexels-photo-9506.jpeg?auto=compress&cs=tinysrgb&w=400',
      food: 'https://images.pexels.com/photos/4009402/pexels-photo-4009402.jpeg?auto=compress&cs=tinysrgb&w=400',
      technology: 'https://images.pexels.com/photos/1649771/pexels-photo-1649771.jpeg?auto=compress&cs=tinysrgb&w=400',
    };

    return defaultImages[domain] || 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400';
  }
}