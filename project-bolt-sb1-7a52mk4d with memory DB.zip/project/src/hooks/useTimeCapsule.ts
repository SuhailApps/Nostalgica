import { useState } from 'react';
import { OnboardingData, TimeCapsule, UserProfile } from '../types';
import { memoryDatabase } from '../services/memoryDatabase';

export const useTimeCapsule = () => {
  const [savedCapsules, setSavedCapsules] = useState<TimeCapsule[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Load user's time capsules from memory database
  const loadUserCapsules = async (userId: string) => {
    setIsLoading(true);
    try {
      const capsules = await memoryDatabase.getUserTimeCapsules(userId);
      setSavedCapsules(capsules);
    } catch (error) {
      console.error('Error loading time capsules:', error);
      alert('Failed to load your time capsules');
    } finally {
      setIsLoading(false);
    }
  };

  const generateTimeCapsule = async (data: OnboardingData, profile: UserProfile): Promise<TimeCapsule> => {
    setIsGenerating(true);
    
    try {
      // This is now handled in TimeCapsuleGenerator component
      // with real LLM and Qloo API calls
      await new Promise(resolve => setTimeout(resolve, 1000));
    
      // Placeholder - actual generation happens in TimeCapsuleGenerator
      const capsule: TimeCapsule = {
        id: Date.now().toString(),
        year: data.year,
        location: data.location || 'Unknown',
        mood: data.mood,
        lifeEvent: data.lifeEvent || '',
        playlist: [],
        starterPack: [],
        memoirSnippet: '',
        thenVsNow: {
          then: { music: [], movies: [], fashion: [], travel: [], food: [] },
          now: { music: [], movies: [], fashion: [], travel: [], food: [] }
        },
        createdAt: new Date(),
        shareableCards: []
      };
    
      return capsule;
    } finally {
      setIsGenerating(false);
    }
  };

  const saveCapsule = async (capsule: TimeCapsule, userId: string) => {
    try {
      const savedCapsule = await memoryDatabase.saveTimeCapsule(capsule, userId);
      setSavedCapsules(prev => [...prev, savedCapsule]);
      return savedCapsule;
    } catch (error) {
      console.error('Error saving time capsule:', error);
      alert('Failed to save time capsule');
      throw error;
    }
  };

  const deleteCapsule = async (capsuleId: string, userId: string) => {
    try {
      await memoryDatabase.deleteTimeCapsule(capsuleId, userId);
      setSavedCapsules(prev => prev.filter(c => c.id !== capsuleId));
    } catch (error) {
      console.error('Error deleting time capsule:', error);
      alert('Failed to delete time capsule');
      throw error;
    }
  };

  const shareCapsule = (capsule: TimeCapsule, format: string) => {
    // Generate shareable content based on format
    const shareUrl = `https://nostalgia-engine.app/capsule/${capsule.id}`;
    
    if (navigator.share) {
      navigator.share({
        title: `My ${capsule.year} Time Capsule`,
        text: capsule.memoirSnippet,
        url: shareUrl,
      });
    } else {
      // Fallback to clipboard
      navigator.clipboard.writeText(shareUrl);
      alert('Link copied to clipboard!');
    }
  };

  return {
    savedCapsules,
    isGenerating,
    isLoading,
    generateTimeCapsule,
    saveCapsule,
    deleteCapsule,
    loadUserCapsules,
    shareCapsule,
  };
};