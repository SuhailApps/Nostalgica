import { useState, useMemo } from 'react';
import { CulturalContent } from '../types';

export const useFilters = (content: CulturalContent[]) => {
  const [selectedDecade, setSelectedDecade] = useState<string>('');
  const [selectedMoods, setSelectedMoods] = useState<string[]>([]);
  const [selectedLifeEvents, setSelectedLifeEvents] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState<string>('');

  const filteredContent = useMemo(() => {
    return content.filter((item) => {
      // Decade filter
      if (selectedDecade && item.decade !== selectedDecade) {
        return false;
      }

      // Mood filter
      if (selectedMoods.length > 0 && !selectedMoods.some(mood => item.mood.includes(mood))) {
        return false;
      }

      // Life events filter
      if (selectedLifeEvents.length > 0 && !selectedLifeEvents.some(event => item.lifeEvents.includes(event))) {
        return false;
      }

      // Search filter
      if (searchTerm) {
        const searchLower = searchTerm.toLowerCase();
        return (
          item.title.toLowerCase().includes(searchLower) ||
          item.description.toLowerCase().includes(searchLower) ||
          item.tags.some(tag => tag.toLowerCase().includes(searchLower))
        );
      }

      return true;
    });
  }, [content, selectedDecade, selectedMoods, selectedLifeEvents, searchTerm]);

  const toggleMood = (mood: string) => {
    setSelectedMoods(prev =>
      prev.includes(mood)
        ? prev.filter(m => m !== mood)
        : [...prev, mood]
    );
  };

  const toggleLifeEvent = (event: string) => {
    setSelectedLifeEvents(prev =>
      prev.includes(event)
        ? prev.filter(e => e !== event)
        : [...prev, event]
    );
  };

  const clearFilters = () => {
    setSelectedDecade('');
    setSelectedMoods([]);
    setSelectedLifeEvents([]);
    setSearchTerm('');
  };

  return {
    selectedDecade,
    selectedMoods,
    selectedLifeEvents,
    searchTerm,
    filteredContent,
    setSelectedDecade,
    setSearchTerm,
    toggleMood,
    toggleLifeEvent,
    clearFilters,
  };
};