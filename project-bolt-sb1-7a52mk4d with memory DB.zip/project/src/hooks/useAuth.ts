import { useState, useEffect } from 'react';
import { memoryDatabase } from '../services/memoryDatabase';
import { UserProfile } from '../types';

export const useAuth = () => {
  const [user, setUser] = useState<any>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Get initial session
    checkUser();

    // Simulate auth state change listener
    const { data: { subscription } } = memoryDatabase.onAuthStateChange(
      async (event, session) => {
        if (event === 'SIGNED_IN' && session?.user) {
          setUser(session.user);
          await loadUserProfile(session.user.id);
        } else if (event === 'SIGNED_OUT') {
          setUser(null);
          setUserProfile(null);
        }
        setLoading(false);
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  const checkUser = async () => {
    try {
      const currentUser = await memoryDatabase.getCurrentUser();
      if (currentUser) {
        setUser(currentUser);
        await loadUserProfile(currentUser.id);
      }
    } catch (error) {
      console.error('Error checking user:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadUserProfile = async (userId: string) => {
    try {
      const profile = await memoryDatabase.getUserProfile(userId);
      setUserProfile(profile);
    } catch (error) {
      console.error('Error loading user profile:', error);
    }
  };

  const signUp = async (email: string, password: string) => {
    const { user, error } = await memoryDatabase.signUp(email, password);
    if (error) {
      throw error;
    }
    setUser(user);
    return user;
  };

  const signIn = async (email: string, password: string) => {
    const { user, error } = await memoryDatabase.signIn(email, password);
    if (error) {
      throw error;
    }
    setUser(user);
    if (user) {
      await loadUserProfile(user.id);
    }
    return user;
  };

  const signOut = async () => {
    const { error } = await memoryDatabase.signOut();
    if (error) {
      throw error;
    }
    setUser(null);
    setUserProfile(null);
  };

  const saveUserProfile = async (profile: UserProfile) => {
    try {
      const savedProfile = await memoryDatabase.saveUserProfile(profile);
      setUserProfile(savedProfile);
      return savedProfile;
    } catch (error) {
      console.error('Error saving user profile:', error);
      throw error;
    }
  };

  return {
    user,
    userProfile,
    loading,
    signUp,
    signIn,
    signOut,
    saveUserProfile,
    loadUserProfile
  };
};