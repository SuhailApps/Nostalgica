export interface CulturalContent {
  id: string;
  title: string;
  type: 'music' | 'movie' | 'news' | 'fashion' | 'technology' | 'event';
  year: number;
  decade: string;
  description: string;
  imageUrl?: string;
  mood: string[];
  lifeEvents: string[];
  popularity: number;
  tags: string[];
}

export interface TimeFilter {
  decade?: string;
  year?: number;
  startYear?: number;
  endYear?: number;
}

export interface MoodFilter {
  selectedMoods: string[];
}

export interface LifeEventFilter {
  selectedEvents: string[];
}

export interface User {
  id: string;
  name: string;
  favoriteEra: string;
  bookmarks: string[];
  timeline: CulturalContent[];
}

export interface OnboardingData {
  decade: string;
  year: number;
  lifeEvent: string;
  mood: string;
  location?: string;
  spotifyData?: any;
  personalityQuiz?: PersonalityQuizResult;
}

export interface LLMProvider {
  id: string;
  name: string;
  baseUrl: string;
  models: string[];
}

export interface UserProfile {
  id: string;
  name?: string;
  email?: string;
  llmProvider: string;
  llmApiKey: string;
  llmModel: string;
  qlooApiKey?: string;
  preferences: {
    defaultDecade?: string;
    favoriteGenres?: string[];
    culturalInterests?: string[];
  };
  createdAt: Date;
  updatedAt: Date;
}

export interface LLMResponse {
  culturalSeeds: {
    music: string[];
    movies: string[];
    fashion: string[];
    food: string[];
    travel: string[];
  };
  memoirSnippet: string;
  thenVsNow: {
    then: {
      music: string[];
      movies: string[];
      fashion: string[];
      travel: string[];
      food: string[];
    };
    now: {
      music: string[];
      movies: string[];
      fashion: string[];
      travel: string[];
      food: string[];
    };
  };
}

export interface QlooRecommendation {
  id: string;
  name: string;
  type: string;
  score: number;
  metadata: {
    artist?: string;
    album?: string;
    year?: number;
    genre?: string;
    director?: string;
    brand?: string;
    category?: string;
    imageUrl?: string;
  };
}

export interface PersonalityQuizResult {
  musicTaste: string;
  movieGenre: string;
  fashionStyle: string;
  lifestyle: string;
}

export interface TimeCapsule {
  id: string;
  year: number;
  location: string;
  mood: string;
  lifeEvent: string;
  playlist: PlaylistItem[];
  starterPack: StarterPackItem[];
  memoirSnippet: string;
  thenVsNow: ThenVsNowComparison;
  createdAt: Date;
  shareableCards: ShareableCard[];
}

export interface PlaylistItem {
  id: string;
  title: string;
  artist: string;
  album?: string;
  imageUrl: string;
  spotifyUrl?: string;
}

export interface StarterPackItem {
  id: string;
  name: string;
  category: 'food' | 'drink' | 'travel' | 'fashion' | 'entertainment' | 'lifestyle';
  icon: string;
  description: string;
}

export interface ThenVsNowComparison {
  then: {
    music: string[];
    movies: string[];
    fashion: string[];
    travel: string[];
    food: string[];
  };
  now: {
    music: string[];
    movies: string[];
    fashion: string[];
    travel: string[];
    food: string[];
  };
}

export interface ShareableCard {
  id: string;
  format: 'instagram-story' | 'tiktok' | 'reels';
  imageUrl: string;
  text: string;
}