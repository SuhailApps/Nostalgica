export const decades = [
  { value: '1980s', label: '1980s', years: Array.from({length: 10}, (_, i) => 1980 + i) },
  { value: '1990s', label: '1990s', years: Array.from({length: 10}, (_, i) => 1990 + i) },
  { value: '2000s', label: '2000s', years: Array.from({length: 10}, (_, i) => 2000 + i) },
  { value: '2010s', label: '2010s', years: Array.from({length: 10}, (_, i) => 2010 + i) },
];

export const moods = [
  { value: 'rebellious', label: 'Rebellious', color: 'from-red-500 to-orange-500', emoji: '🔥' },
  { value: 'glam', label: 'Glam', color: 'from-pink-500 to-purple-500', emoji: '✨' },
  { value: 'nerdy', label: 'Nerdy', color: 'from-blue-500 to-indigo-500', emoji: '🤓' },
  { value: 'optimistic', label: 'Optimistic', color: 'from-yellow-400 to-orange-400', emoji: '☀️' },
  { value: 'futuristic', label: 'Futuristic', color: 'from-cyan-500 to-blue-500', emoji: '🚀' },
  { value: 'chill', label: 'Chill', color: 'from-green-400 to-teal-400', emoji: '🌿' },
  { value: 'intense', label: 'Intense', color: 'from-purple-600 to-pink-600', emoji: '⚡' },
];

export const lifeEventTemplates = [
  'My punk phase in California',
  'College years in New York',
  'First job in tech',
  'Backpacking through Europe',
  'High school graduation',
  'Moving to a new city',
  'Starting a band',
  'Art school days',
  'Summer of love',
  'Quarter-life crisis',
];

export const personalityQuestions = [
  {
    id: 1,
    question: "What's your ideal Friday night?",
    options: [
      { value: 'concert', label: 'Live music venue or concert', points: { rebellious: 3, intense: 2 } },
      { value: 'movie', label: 'Movie marathon at home', points: { chill: 3, nerdy: 2 } },
      { value: 'party', label: 'House party with friends', points: { glam: 3, optimistic: 2 } },
      { value: 'explore', label: 'Exploring new places', points: { futuristic: 3, optimistic: 2 } },
    ]
  },
  {
    id: 2,
    question: "Pick your fashion inspiration:",
    options: [
      { value: 'vintage', label: 'Vintage thrift finds', points: { rebellious: 2, chill: 3 } },
      { value: 'designer', label: 'Designer brands', points: { glam: 3, intense: 1 } },
      { value: 'comfort', label: 'Comfort over style', points: { chill: 3, nerdy: 2 } },
      { value: 'trendy', label: 'Latest trends', points: { futuristic: 3, optimistic: 2 } },
    ]
  },
  {
    id: 3,
    question: "Your music discovery method:",
    options: [
      { value: 'underground', label: 'Underground scenes', points: { rebellious: 3, intense: 2 } },
      { value: 'algorithm', label: 'Spotify algorithms', points: { futuristic: 3, nerdy: 2 } },
      { value: 'friends', label: 'Friend recommendations', points: { optimistic: 3, chill: 2 } },
      { value: 'charts', label: 'Top charts', points: { glam: 2, optimistic: 2 } },
    ]
  },
];