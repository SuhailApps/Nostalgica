import { CulturalContent } from '../types';

export const culturalContent: CulturalContent[] = [
  {
    id: '1',
    title: 'I Want to Hold Your Hand - The Beatles',
    type: 'music',
    year: 1963,
    decade: '1960s',
    description: 'The song that launched Beatlemania in America',
    imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=400',
    mood: ['Happy', 'Nostalgic', 'Energetic'],
    lifeEvents: ['First Love', 'Youth', 'School Days'],
    popularity: 95,
    tags: ['rock', 'pop', 'british-invasion']
  },
  {
    id: '2',
    title: 'Woodstock Music Festival',
    type: 'event',
    year: 1969,
    decade: '1960s',
    description: 'Three days of peace, love, and music that defined a generation',
    imageUrl: 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=400',
    mood: ['Nostalgic', 'Peaceful', 'Revolutionary'],
    lifeEvents: ['Coming of Age', 'Freedom', 'Youth'],
    popularity: 90,
    tags: ['music-festival', 'counterculture', 'peace']
  },
  {
    id: '3',
    title: 'Star Wars: A New Hope',
    type: 'movie',
    year: 1977,
    decade: '1970s',
    description: 'The space opera that changed cinema forever',
    imageUrl: 'https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=400',
    mood: ['Adventurous', 'Nostalgic', 'Epic'],
    lifeEvents: ['Childhood', 'First Movie Theater', 'Growing Up'],
    popularity: 98,
    tags: ['sci-fi', 'adventure', 'space']
  },
  {
    id: '4',
    title: 'Disco Fever',
    type: 'music',
    year: 1977,
    decade: '1970s',
    description: 'The height of disco culture and dance floor magic',
    imageUrl: 'https://images.pexels.com/photos/9506/pexels-photo-9506.jpeg?auto=compress&cs=tinysrgb&w=400',
    mood: ['Energetic', 'Happy', 'Party'],
    lifeEvents: ['First Dance', 'Nightlife', 'Youth'],
    popularity: 85,
    tags: ['disco', 'dance', 'nightlife']
  },
  {
    id: '5',
    title: 'MTV Launches',
    type: 'event',
    year: 1981,
    decade: '1980s',
    description: 'Music television revolutionizes pop culture',
    imageUrl: 'https://images.pexels.com/photos/9292/pexels-photo-9292.jpeg?auto=compress&cs=tinysrgb&w=400',
    mood: ['Energetic', 'Revolutionary', 'Modern'],
    lifeEvents: ['Teenage Years', 'Pop Culture Awakening'],
    popularity: 88,
    tags: ['television', 'music-videos', 'pop-culture']
  },
  {
    id: '6',
    title: 'Back to the Future',
    type: 'movie',
    year: 1985,
    decade: '1980s',
    description: 'Time travel adventure that captured imaginations',
    imageUrl: 'https://images.pexels.com/photos/8721342/pexels-photo-8721342.jpeg?auto=compress&cs=tinysrgb&w=400',
    mood: ['Adventurous', 'Nostalgic', 'Fun'],
    lifeEvents: ['Childhood', 'Family Movie Night'],
    popularity: 92,
    tags: ['sci-fi', 'comedy', 'time-travel']
  },
  {
    id: '7',
    title: 'Nirvana - Smells Like Teen Spirit',
    type: 'music',
    year: 1991,
    decade: '1990s',
    description: 'The anthem that brought grunge to mainstream',
    imageUrl: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=400',
    mood: ['Rebellious', 'Energetic', 'Angsty'],
    lifeEvents: ['Teenage Rebellion', 'High School', 'Coming of Age'],
    popularity: 94,
    tags: ['grunge', 'alternative', 'rock']
  },
  {
    id: '8',
    title: 'Friends TV Show Premieres',
    type: 'event',
    year: 1994,
    decade: '1990s',
    description: 'The sitcom that defined friendship for a generation',
    imageUrl: 'https://images.pexels.com/photos/4009402/pexels-photo-4009402.jpeg?auto=compress&cs=tinysrgb&w=400',
    mood: ['Happy', 'Nostalgic', 'Cozy'],
    lifeEvents: ['College Years', 'Young Adulthood', 'Friendship'],
    popularity: 89,
    tags: ['sitcom', 'friendship', 'coffee-culture']
  },
  {
    id: '9',
    title: 'iPod Launch',
    type: 'technology',
    year: 2001,
    decade: '2000s',
    description: '1,000 songs in your pocket - music revolution',
    imageUrl: 'https://images.pexels.com/photos/1649771/pexels-photo-1649771.jpeg?auto=compress&cs=tinysrgb&w=400',
    mood: ['Innovative', 'Modern', 'Sleek'],
    lifeEvents: ['First Job', 'Digital Age', 'Music Discovery'],
    popularity: 91,
    tags: ['technology', 'music', 'portable']
  },
  {
    id: '10',
    title: 'Social Media Birth',
    type: 'technology',
    year: 2004,
    decade: '2000s',
    description: 'Facebook launches, changing how we connect',
    imageUrl: 'https://images.pexels.com/photos/267350/pexels-photo-267350.jpeg?auto=compress&cs=tinysrgb&w=400',
    mood: ['Social', 'Connected', 'Revolutionary'],
    lifeEvents: ['College', 'Networking', 'Digital Identity'],
    popularity: 87,
    tags: ['social-media', 'networking', 'digital']
  }
];

export const decades = ['1950s', '1960s', '1970s', '1980s', '1990s', '2000s', '2010s', '2020s'];

export const moods = [
  'Happy', 'Nostalgic', 'Melancholy', 'Energetic', 'Peaceful', 'Rebellious', 
  'Romantic', 'Adventurous', 'Cozy', 'Epic', 'Fun', 'Revolutionary'
];

export const lifeEvents = [
  'First Love', 'Graduation', 'Wedding', 'First Job', 'Childhood', 'Teenage Years',
  'College', 'Retirement', 'Youth', 'Coming of Age', 'Parenthood', 'Growing Up'
];