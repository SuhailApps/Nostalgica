import React from 'react';
import { useState } from 'react';
import GlobalHeader from './components/GlobalHeader';
import ProfilePage from './components/ProfilePage';
import OnboardingFlow from './components/onboarding/OnboardingFlow';
import TimeCapsuleGenerator from './components/TimeCapsuleGenerator';
import TimeCapsuleDashboard from './components/TimeCapsuleDashboard';
import TimeCapsuleLibrary from './components/TimeCapsuleLibrary';
import AuthPage from './components/AuthPage';
import { OnboardingData, TimeCapsule, UserProfile } from './types';
import { useTimeCapsule } from './hooks/useTimeCapsule';
import { useAuth } from './hooks/useAuth';
import { Clock, Sparkles, ArrowRight } from 'lucide-react';

function App() {
  const [currentView, setCurrentView] = useState<'landing' | 'profile' | 'onboarding' | 'generating' | 'dashboard' | 'library' | 'explore'>('landing');
  const [onboardingData, setOnboardingData] = useState<OnboardingData | null>(null);
  const [currentCapsule, setCurrentCapsule] = useState<TimeCapsule | null>(null);
  const { user, userProfile, loading, signIn, signUp, signOut, saveUserProfile } = useAuth();
  const { savedCapsules, saveCapsule, deleteCapsule, loadUserCapsules, shareCapsule, isLoading } = useTimeCapsule();

  // Load user's capsules when user changes
  React.useEffect(() => {
    if (user && userProfile) {
      loadUserCapsules(user.id);
    }
  }, [user, userProfile]);

  const handleStartOnboarding = () => {
    if (!user) {
      alert('Please sign in to create time capsules');
      return;
    }
    if (!userProfile || !userProfile.llmApiKey) {
      alert('Please set up your profile with both LLM and Qloo API keys first');
      setCurrentView('profile');
    } else {
      setCurrentView('onboarding');
    }
  };

  const handleProfileSave = (profile: UserProfile) => {
    if (!user) {
      alert('Please sign in first');
      return;
    }
    
    const profileWithUserId = { ...profile, id: user.id };
    saveUserProfile(profileWithUserId)
      .then(() => {
        alert('Profile saved successfully!');
      })
      .catch((error) => {
        console.error('Error saving profile:', error);
        alert('Failed to save profile');
      });
  };

  const handleOnboardingComplete = (data: OnboardingData) => {
    setOnboardingData(data);
    setCurrentView('generating');
  };

  const handleGenerationComplete = (capsule: TimeCapsule) => {
    setCurrentCapsule(capsule);
    setCurrentView('dashboard');
  };

  const handleSaveCapsule = () => {
    if (currentCapsule && user) {
      saveCapsule(currentCapsule, user.id)
        .then(() => {
          alert('Time capsule saved!');
        })
        .catch((error) => {
          console.error('Error saving capsule:', error);
        });
    }
  };

  const handleShareCapsule = (format: string) => {
    if (currentCapsule) {
      shareCapsule(currentCapsule, format);
    }
  };

  const handleExploreMore = () => {
    setCurrentView('landing');
    setOnboardingData(null);
    setCurrentCapsule(null);
  };

  const handleCancel = () => {
    setCurrentView('landing');
    setOnboardingData(null);
    setCurrentCapsule(null);
  };

  const handleViewLibrary = () => {
    setCurrentView('library');
  };

  const handleViewCapsule = (capsule: TimeCapsule) => {
    setCurrentCapsule(capsule);
    setCurrentView('dashboard');
  };

  const handleNavigate = (view: string) => {
    setCurrentView(view as any);
    // Reset states when navigating
    if (view === 'landing') {
      setOnboardingData(null);
      setCurrentCapsule(null);
    }
  };

  // Show loading screen while checking authentication
  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-100 via-pink-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <Clock className="w-16 h-16 text-purple-600 mx-auto mb-4 animate-spin" />
          <p className="text-xl text-gray-700">Loading...</p>
        </div>
      </div>
    );
  }

  // Show auth page if user is not signed in
  if (!user) {
    return <AuthPage onSignIn={signIn} onSignUp={signUp} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-pink-50 to-indigo-100">
      {/* Global Header - Always Visible */}
      <GlobalHeader
        currentView={currentView}
        userProfile={userProfile}
        savedCapsulesCount={savedCapsules.length}
        onNavigate={handleNavigate}
      />

      {currentView === 'landing' && (
        <div>
          {/* Animated Background Pattern */}
          <div className="fixed inset-0 opacity-10 pointer-events-none">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(120,119,198,0.3),transparent)] animate-pulse"></div>
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(255,182,193,0.4),transparent)] animate-pulse delay-1000"></div>
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_80%,rgba(186,225,255,0.3),transparent)] animate-pulse delay-2000"></div>
          </div>

          {/* Hero Section */}
          <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
            <div className="mb-12">
              <div className="flex items-center justify-center gap-4 mb-6">
                <Clock className="w-16 h-16 text-purple-600" />
                <Sparkles className="w-12 h-12 text-pink-500 animate-pulse" />
              </div>
              
              <h1 className="text-6xl font-bold bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 bg-clip-text text-transparent mb-6">
                Nostalgia Engine
              </h1>
              
              <p className="text-2xl text-gray-700 mb-8 max-w-2xl mx-auto">
                Travel back in time and rediscover the cultural moments that shaped who you are today
              </p>
              
              <button
                onClick={handleStartOnboarding}
                className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white text-xl font-semibold rounded-2xl hover:shadow-2xl hover:scale-105 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={!userProfile?.llmApiKey}
              >
                Create Your Time Capsule
                <ArrowRight className="w-6 h-6" />
              </button>
              <button
                onClick={() => signOut()}
                className="ml-4 px-6 py-3 bg-gray-500 text-white rounded-xl hover:bg-gray-600 transition-colors"
              >
                Sign Out
              </button>
            </div>
              
              {!userProfile?.llmApiKey && (
                <p className="text-sm text-gray-600 mt-2">
                  Please set up your profile with LLM API key to get started
                </p>
              )}

            {/* Features Preview */}
            <div className="grid md:grid-cols-3 gap-8 mt-16">
              <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-xl">
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-6 h-6 text-purple-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-2">Time Travel</h3>
                <p className="text-gray-600">Journey through decades and relive your most memorable cultural moments</p>
              </div>
              
              <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-xl">
                <div className="w-12 h-12 bg-pink-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Sparkles className="w-6 h-6 text-pink-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-2">AI-Powered</h3>
                <p className="text-gray-600">Advanced AI curates personalized playlists, memories, and cultural insights</p>
              </div>
              
              <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-xl">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <ArrowRight className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-2">Share & Connect</h3>
                <p className="text-gray-600">Create shareable time capsules for social media and connect with others</p>
              </div>
            </div>

            {/* Saved Capsules */}
            {savedCapsules.length > 0 && (
              <div className="mt-16">
                <div className="flex items-center justify-between mb-8">
                  <h2 className="text-3xl font-bold text-gray-800">Your Time Capsules</h2>
                  <button
                    onClick={handleViewLibrary}
                    className="flex items-center gap-2 px-4 py-2 bg-purple-500 text-white rounded-xl hover:bg-purple-600 transition-colors"
                  >
                    <Clock className="w-5 h-5" />
                    View All Capsules
                  </button>
                </div>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {savedCapsules.slice(0, 6).map((capsule) => (
                    <div key={capsule.id} className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-xl hover:shadow-2xl transition-shadow cursor-pointer">
                      <div className="text-2xl font-bold text-purple-600 mb-2">{capsule.year}</div>
                      <div className="text-gray-700 font-medium mb-2">{capsule.location}</div>
                      <div className="text-sm text-gray-600 mb-4">{capsule.lifeEvent}</div>
                      <div className="text-xs text-gray-500">
                        Created {capsule.createdAt.toLocaleDateString()}
                      </div>
                    </div>
                  ))}
                </div>
                {savedCapsules.length > 6 && (
                  <div className="text-center mt-6">
                    <p className="text-gray-600">
                      And {savedCapsules.length - 6} more capsules...
                    </p>
                  </div>
                )}
              </div>
            )}
          </main>
        </div>
      )}

      {currentView === 'explore' && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-2xl p-8 text-center">
            <Clock className="w-16 h-16 text-purple-600 mx-auto mb-4" />
            <h1 className="text-3xl font-bold text-gray-800 mb-4">Explore Capsules</h1>
            <p className="text-gray-600 mb-6">
              Discover time capsules from other users and explore different eras and cultures.
            </p>
            <p className="text-sm text-gray-500">
              This feature is coming soon! For now, create your own time capsules and build your personal collection.
            </p>
          </div>
        </div>
      )}

      {currentView === 'profile' && (
        <ProfilePage
          onBack={() => handleNavigate('landing')}
          onSave={handleProfileSave}
          currentProfile={userProfile || undefined}
        />
      )}

      {currentView === 'onboarding' && (
        <OnboardingFlow
          onComplete={handleOnboardingComplete}
          onCancel={handleCancel}
        />
      )}

      {currentView === 'generating' && onboardingData && userProfile && (
        <TimeCapsuleGenerator
          onboardingData={onboardingData}
          userProfile={userProfile}
          onComplete={handleGenerationComplete}
          onCancel={handleCancel}
        />
      )}

      {currentView === 'dashboard' && currentCapsule && (
        <TimeCapsuleDashboard
          capsule={currentCapsule}
          onShare={handleShareCapsule}
          onSave={handleSaveCapsule}
          onExploreMore={handleExploreMore}
        />
      )}

      {currentView === 'library' && (
        <TimeCapsuleLibrary
          capsules={savedCapsules}
          isLoading={isLoading}
          onBack={() => handleNavigate('landing')}
          onViewCapsule={handleViewCapsule}
          onDeleteCapsule={(capsuleId) => user && deleteCapsule(capsuleId, user.id)}
        />
      )}

      {/* Footer - only show on landing */}
      {currentView === 'landing' && (
        <footer className="bg-gray-900/90 text-white py-8 mt-16 relative z-10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <p className="text-gray-300">
              Travel through time and rediscover the cultural moments that shaped our world
            </p>
            <p className="text-sm text-gray-400 mt-2">
              © 2025 Nostalgia Engine • Powered by memories and imagination
            </p>
          </div>
        </footer>
      )}
    </div>
  );
}

export default App;