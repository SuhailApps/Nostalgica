/*
  # Create users and time capsules tables

  1. New Tables
    - `users`
      - `id` (uuid, primary key)
      - `email` (text, unique)
      - `name` (text)
      - `llm_provider` (text)
      - `llm_api_key` (text, encrypted)
      - `llm_model` (text)
      - `qloo_api_key` (text, encrypted)
      - `preferences` (jsonb)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `time_capsules`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key)
      - `year` (integer)
      - `location` (text)
      - `mood` (text)
      - `life_event` (text)
      - `playlist` (jsonb)
      - `starter_pack` (jsonb)
      - `memoir_snippet` (text)
      - `then_vs_now` (jsonb)
      - `shareable_cards` (jsonb)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users to manage their own data
*/

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE,
  name text,
  llm_provider text NOT NULL DEFAULT 'openai',
  llm_api_key text NOT NULL,
  llm_model text NOT NULL DEFAULT 'gpt-4',
  qloo_api_key text,
  preferences jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create time_capsules table
CREATE TABLE IF NOT EXISTS time_capsules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  year integer NOT NULL,
  location text NOT NULL,
  mood text NOT NULL,
  life_event text NOT NULL,
  playlist jsonb DEFAULT '[]',
  starter_pack jsonb DEFAULT '[]',
  memoir_snippet text,
  then_vs_now jsonb DEFAULT '{"then": {"music": [], "movies": [], "fashion": [], "travel": [], "food": []}, "now": {"music": [], "movies": [], "fashion": [], "travel": [], "food": []}}',
  shareable_cards jsonb DEFAULT '[]',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE time_capsules ENABLE ROW LEVEL SECURITY;

-- Create policies for users table
CREATE POLICY "Users can read own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own data"
  ON users
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own data"
  ON users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Create policies for time_capsules table
CREATE POLICY "Users can read own time capsules"
  ON time_capsules
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own time capsules"
  ON time_capsules
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own time capsules"
  ON time_capsules
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own time capsules"
  ON time_capsules
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_time_capsules_user_id ON time_capsules(user_id);
CREATE INDEX IF NOT EXISTS idx_time_capsules_year ON time_capsules(year);
CREATE INDEX IF NOT EXISTS idx_time_capsules_mood ON time_capsules(mood);
CREATE INDEX IF NOT EXISTS idx_time_capsules_created_at ON time_capsules(created_at);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_users_updated_at
  BEFORE UPDATE ON users
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_time_capsules_updated_at
  BEFORE UPDATE ON time_capsules
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();